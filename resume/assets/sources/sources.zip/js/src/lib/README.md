# This dir.
Here we keep only files which can be useful in other projects, non-app specific.