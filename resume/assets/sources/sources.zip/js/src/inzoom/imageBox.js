/**
* Simple 'box' (new layer) script. Specific to the inzoom project,
* this one shows the **image**, it's not a 'generic' box or dialog box or something.
*/

class ImageBox{
    /**
     * @param config - a config object from the app object
     */
    constructor(config){
        this.config = config;
        this.codeElement = this.widgetElement = this.imageWrapperElement = this.imageElement = null;
        //img src, img full src etc:
        this.elementInfo = {};
        this.originalSrc = null;//full original content url (src)
        //original, or high res (if any). NOT 'on screen'.
        this.imageNaturalSize = {width:null,height:null};
        // based on mousemove - relative to document
        this.mousePos = new Point();
    }

    //if this file is local, it should first go to manifest: web_accessible_resources
    async readFile(path){
        let response = await fetch(path);
        let data = await response.text();
        return data;
    }
    /**
     * Creating the box, not displaying anything yet (there is the .show method for this)
     * Will be auto created with first call to .show
     */
    async create(){
        let that = this;
        if(this.isCreated()){//already done that
            return;
        }
        // let url = browser.runtime.getURL("inzoom/views/imageBox.html");
        let url = chrome.runtime.getURL("inzoom/views/imageBox.html");
        let html = await this.readFile(url);
        var cleanHtml = DOMPurify.sanitize(html,{ADD_TAGS: ['use']});

        //Sanitized by DOMPurify.
        document.querySelector('body').insertAdjacentHTML('beforeend',cleanHtml);
        this.codeElement = document.querySelector('.inzoom-imagebox-code');
        this.widgetElement = document.querySelector('.inzoom-imagebox-widget');
        this.imageWrapperElement = this.q('.inzoom-imagebox-content-wrapper');
        this.imageElement = this.q('.inzoom-imagebox-image');
        
        //info part
        this.infoElement = this.q('.inzoom-imagebox-info-wrapper');

        //event handlers, specific to our box dom (e.g. wheel on our element, draggable on our element)
        //Hamster(this.imageElement).wheel((...params) => this.onWheel(...params));
        Hamster(this.imageWrapperElement).wheel((...params) => this.onWheel(...params));
        this.imageElement.inzoomDraggableInstance = new ElementDraggable(this.imageElement);

        document.addEventListener('mousemove',(e) => {
            this.onMouseMove(e);
        })
        document.addEventListener('click',(e) => {
            this.onClick(e);
        })
        document.addEventListener('keydown', (e) => {
            this.onKeyDown(e);
        }, true); 

        //anything on the toolbar (but we're interested only on the palette part)
        this.q('.inzoom-imagebox-toolbar').addEventListener('click',(e) => {
            let paletteTool = e.target.closest('div[data-inzoom-imagebox-t-palette-tool]');
            if(paletteTool){
                this.onToolbarPaletteCommand(paletteTool.getAttribute('data-inzoom-imagebox-t-palette-tool'));
            }
        })        

        //specific toolbar buttons
        this.q('.inzoom-imagebox-t-info').addEventListener('click',(e)=>{
            this.onProperties(e);
        })

        this.q('.inzoom-imagebox-t-reset').addEventListener('click',(e) => {
            this.resetImage();//whatever style we added, now it's removed
        })
        return this.codeElement;
         
    }
    
    /**
    * @param elementInfo: object with props:
    *   src: e.g. img src.
    *   fullResolution: full image/video/whatever src, usually from a href = ... 
    *   which might be a parent of img. It is utils.js job to find it out (src/inzoom/utils.js)
    *   not this class. Or maybe FullResolutionLocator.js
    *   this elementInfo does NOT include DOM element itself (we can't send DOM elements between background and content scripts)
    * 
    */
    show(elementInfo){
        //logger.log('imageBox show:',elementInfo)
        this.elementInfo = elementInfo;
        if(!this.elementInfo.src){
            return;
        }
        if(!this.isCreated()){
            this.create();
            //.create takes some time, before the dom is ready, i'm pretty lazy today, no time for this DOM MutationObserver
            setTimeout(()=>{
                return this.show(elementInfo);
            },200)
            return;
        }
        this.widgetElement.classList.add('inzoom-imagebox-widget-visible');
        this.update();

    }

    //setting the image element's src attr, plus a few other details.
    //it's a separate method, since we can do it multiple times (at startup, then with high res image)
    loadImage(src){
        let img = new Image();
        img.onerror = img.onabort = function() {
            logger.log('error');
        };
        img.onload = ()=>{
            this.imageElement.setAttribute('src',src);
            //p.s. this.imageElement.naturalWidth does not work on chrome
            this.imageNaturalSize = {width: img.width, height: img.height};
        };
        img.src = src;        
    }

    //called by .show
    update(){
        //this one must be always here:
        this.loadImage(this.elementInfo.src);
        this.originalSrc = this.elementInfo.src;
        
        // now we'll try to get a higher (full) resolution version
        // we'll not be examining the url's extension of course, we'll simply try to load the image
        // and if it works, we'll replace our box' img with this one.
        if(this.elementInfo.fullResolution){
            this.loadImage(this.elementInfo.fullResolution);
        }
    }

    resetImage(){
        this.imageElement.setAttribute('style','');//whatever style we added, now it's removed
    };

    hide (){
        this.widgetElement.classList.remove('inzoom-imagebox-widget-visible');
        this.infoHide();
        this.resetImage();
    };

    isCreated(){
        return this.widgetElement !== null;
    }

    //i.e. created and visible right now.
    isActive(){
        if(!this.isCreated()){
            return false;
        }
        const active = this.widgetElement.classList.contains('inzoom-imagebox-widget-visible');
        return active;
    }

    //info part (dlg)
    infoShow(){
        this.infoElement.classList.add('inzoom-imagebox-info-wrapper-visible');
    }
    infoHide(){
        this.infoElement.classList.remove('inzoom-imagebox-info-wrapper-visible');
    }
    infoIsActive(){
        this.infoElement.classList.contains('inzoom-imagebox-info-wrapper-visible');
    }

    //shortcut
    q(selector){
        return this.codeElement.querySelector(selector);
    }

   
    // mousemove on document
    onMouseMove(e){
        //relative to document
        this.mousePos.set(e.clientX,e.clientY);
    }

    // on ** document ** 
    onClick(e){
        //was it our box?
        let itsUs = e.target.closest('.inzoom-imagebox-widget') !== null;
        if(!itsUs){
            this.hide();
        }
    }

    //wheel somewhere on the **image**
    onWheel(event, delta, deltaX, deltaY){
        event.originalEvent.preventDefault();//problem when non - passive: https://www.chromestatus.com/features/6662647093133312
        //logger.log(this.imageElement);
        this.zoom(this.imageElement,deltaX, deltaY);
    }

    zoom(element, deltaX, deltaY){
        //should we zoom IN or OUT
        let enlarge = null;
        if(this.config.get('zoom.wheel.direction') == 0){
            enlarge = deltaY > 0;
        }else{
            enlarge = deltaY < 0;
        }
        function r(x) {
            return Math.round(x);
        }   
        let ratio = enlarge ? 1.1:0.9;
        let computedStyle = window.getComputedStyle(element);
        let imageWidth = parseInt(computedStyle.width);
        let imageHeight = parseInt(computedStyle.height);

        let computedWrapperStyle = window.getComputedStyle(this.imageWrapperElement);
        let wrapperWidth = parseInt(computedWrapperStyle.width);
        let wrapperHeight = parseInt(computedWrapperStyle.height);
        let rect = this.imageWrapperElement.getBoundingClientRect();
        let relativeMousePos = new Point(this.mousePos.x - rect.left, this.mousePos.y - rect.top);

        //this.transformElement(lElement,ratio);    
        let transform = computedStyle.transform;
        if(transform === '' || transform === 'none'){
            transform = 'matrix(1,0,0,1,0,0)';
        }         
        //hmmm it seems to work o.O and no - it doesn't accumulate, it's more like recalculated.   
        element.style.transform = transform + ' ' + ` scale(${ratio},${ratio})`;

        /////////
        //zaczęte porzuszanie tak aby celowało w miejsce gdzie jest mysz... nie no, trzeba jednak chyba używać translate

        let curPos = new Point(parseInt(element.style.left) || 0, parseInt(element.style.top) || 0);
        let newPos = new Point(curPos);
        
        let distFromCenterX = (wrapperWidth / 2) - relativeMousePos.x;
        let distFromCenterY = (wrapperHeight / 2) - relativeMousePos.y;
        let offsetX =  distFromCenterX/10;
        let offsetY =  distFromCenterY/10;
        if(!enlarge){
            offsetY *= -1;
            offsetX *= -1;
        }
        newPos.add(offsetX, offsetY);
        // logger.log(`
        //     wrappertHeight: ${r(wrapperHeight)}  (center: ${r(wrapperHeight / 2 )})  
        //     relMouseY: ${r(relativeMousePos.y)}, 
        //     distY: ${r(distFromCenterY)} 
        //     offsetY: ${r(offsetY)} `);
        if(true){
            element.style.position = 'relative';
            element.style.left = newPos.x + 'px';
            element.style.top = newPos.y + 'px';
        }
    }

    //rotate etc.
    onToolbarPaletteCommand(which){
        const elementTransformations = new ElementTransformations(this.imageElement);
        elementTransformations.transformFromPalette(which, true);        
    }

    //'info' toolbar command
    onProperties(e){
        let info = `Original:\n${this.originalSrc}`;
        info += `\n\nHigh resulution:\n`;
        logger.log(this.elementInfo.fullResolution, this.originalSrc);
        if(this.elementInfo.fullResolution === null || this.elementInfo.fullResolution === this.originalSrc){
            info += 'Not found';
        } else {
            info += this.imageElement.src;
        };   

        //alert(info);
        this.infoShow();
    }

    onKeyDown(e){
        if(e.keyCode == 27){
            if(this.isActive()){
                e.preventDefault();
                e.stopPropagation();
                if(this.infoIsActive()){
                    this.infoHide();
                }else{
                    this.hide();
                }
            }
        }
    }
    //not used anymore.
    // destroy(){
    //     if(this.widgetElement){
    //         this.widgetElement.remove();
    //     }        
        
    //     this.widgetElement = this.imageElement = null;
    //     this.elementInfo = {};
    // }    
}