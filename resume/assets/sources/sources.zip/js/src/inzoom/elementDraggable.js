/*
This takes care about moving (dragging) DOM Elements.
It works by creating a new instance for every element, which is to be draggable.
@todo move it to a separate file.
*/
class ElementDraggable{

    constructor(element = null){

        this.lelement = null;
        this.lastMousePos = new Point();
        this.mouseIsDown = false;
        this.wasMovement = false;
        if(element){
            this.attach(element);
        }

    }

    attach(element){
        this.lelement = l(element);
        element.classList.add('inzoom-draggable');

        this.lelement.on('mousedown', (event) => {
            if(event.button === 0){//left mouse button
                this.mouseIsDown = true;
                this.lelement[0].classList.add('inzoom-dragging');
                //'offset' relative to top/left of clicked element. So if clicked at exactly topleft we'll have 0,0 here  
                //10,0 means 10 pixels to the right
                //offset.set(event.clientX - div.offsetLeft, event.clientY - div.offsetTop); 
                //było offset = :
                //x: div.offsetLeft - e.clientX,
                //y: div.offsetTop - e.clientY
                
                this.lastMousePos.set(event.clientX, event.clientY);

                //preventing entering the 'drag' mode in FX.
                //this is required by fx when img (or other element) is in <a href...>, 
                //even doing 'preventDefault' on 'dragStart' doesn't help
                event.preventDefault();

          }
    
        }, true);
    
        document.addEventListener('mouseup', () => {
            this.lelement[0].classList.remove('inzoom-dragging');
            this.mouseIsDown = false;
        }, true);
    
        document.addEventListener('mousemove', (event) => {
            
            if (this.mouseIsDown) {
                event.preventDefault();
                this.wasMovement = true;
                //we want to know a difference in position, between last (starting) mouse pos and current mouse pos.
                //this will give us an idea about how much move the element (we can't use absolute values here, with transformations, afaik) 
                let offset = new Point(event.clientX - this.lastMousePos.x, event.clientY - this.lastMousePos.y);
                let computedStyle = window.getComputedStyle(this.lelement[0]);
                //by def. it's 'none'
                let transform = computedStyle.transform;  
                if(transform === 'none'){
                    transform = '';
                }else{
                    let arTransform = this.transformationFromString(transform);
                    if(arTransform){
                        if(arTransform[0] != 0 && arTransform[3]){
                            offset.divide((arTransform[0]), (arTransform[3]));
                        }
                    }
                }
                //we cannot do div.style.transform+=... because if transformations are set in .css it won't be here. 
                this.lelement[0].style.transform = transform + ` translate(${offset.x}px,${offset.y}px)`;
                this.lastMousePos.set(event.clientX, event.clientY);
            }
        }, true);      

        //fx seems to require it on linked images. 
        //Or maybe not, preventDefault on mouseDown seems to do the job
        /*
        this.lelement.on("dragstart", function( event ) {
            event.preventDefault();
            event.stopPropagation();
            console.log('prevented dragstart');
            return false;            
        }, false);        
        */

        this.lelement.on('click', (event) => {
            let preventDefault = false;
            if(this.wasMovement){
                preventDefault = true;
            }
            this.wasMovement = false;
            if(preventDefault){
                event.preventDefault();
                event.stopPropagation();
                return false;
            }   
        },true)   

        document.addEventListener('keydown', (event) => {
            //maybe for some reason we got crazy with our dragdropping, and user pressed escape. 
            if (this.mouseIsDown && event.keyCode == 27){
                this.mouseIsDown = false;
                this.lelement[0].classList.remove('inzoom-dragging');
            }
            
           
        }, true);

        
    }

    /*
    returns an array of matrix values, i.e. from a string 'matrix(1,0,0,1,0,0)' it will return an array of 7 values.
    used by getElementTransform and maybe others.
    returns null if string doesn't match anything sensible. 
    @param string  transformationString - cannot be empty or 'none', that can of validation should be done earlier, will return
    null in those cases. 
    */
    transformationFromString(transformationString){
        let regex = /\((.*?),(.*?),(.*?),(.*?),(.*?),(.*?)\)/;
        let arTransform = transformationString.match(regex);  
        if(arTransform.length >  0){//it should be 7, but this test is future proof! :) 
            return arTransform.slice(1);//the first elem. is the whole match, which we don't want
        }
        return null;
    }

    /*
    returns a DOM element transform matrix as an array.
    when no modifications are done, then on positions 0 and 3 we have scale x and y, then on positions 5,6 we have translation.
    */
    getElementTransform(element){
        let computedStyle = window.getComputedStyle(element);
        //by def. it's 'none'
        let transform = computedStyle.transform;
        if(transform === '' || transform === 'none'){
            transform = 'matrix(1,0,0,1,0,0)';//default
        }
        return transformationFromString(transform);
    }

    /*
    var div;
    var isDown = false;
    var lastMousePos = new Point();
    
    
    div  = l('.inzoomMoveable');
    console.log('matrix:',getElementTransform(div));
    */
  
}
