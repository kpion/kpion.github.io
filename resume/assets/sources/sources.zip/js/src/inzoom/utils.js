/**
 * Misc. stuff used by inzoom module.
 */
class Utils{

    /**
     * Returns an inline style, i.e. element.style - this one works both in FX and Chrome (other methods have
     * some issues in one or the other) e.g. in Fx it's not really a simple object, instead it's a 
     * CSSStyleDeclaration and... this isn't cool in some scenarios.
     * 
     * Useful for making a 'backup' of user defined inline-style before changing it, so we can later modify it.  
     * @param HTMLElement element 
     * @return object with styles *modfied* by user. Otherwise it's not there. 
     */
    static getElementInlineStyle(element){
        var style = element.style;
        var result = {}; 
        for(let i = 0; i < element.style.length; i++) {
            let propName = style.item(i);
            //console.log(`Key: "${propName}" Value: "${styleDeclaration.getPropertyValue(propName)}"`);
            result[propName] = style.getPropertyValue(propName);
        }
        return result;
    }

    /**
     * This one is just a sort of alias for window.getComputedStyle, just for consistency with the getElementInlineStyle
     */
    static getElementComputedStyle(element, pseudoElement = null){
        return getComputedStyle(element, pseudoElement);
    }

    /*
    will return an element information, in the context of our needs, 
    see 'result' object definition for more. 
    Used by both inzoom.js and imageBox.js
    */    
    static getElementInfo(lElement){
        
        let result = {
            type : null, //img, background-image
            lElement : null,
        };
        let hElem = lElement[0];
        
        if(lElement.is('img')){
            result.type = 'img';
            result.src = lElement.attr('src');
        }

        if(result.type === null && lElement.is('svg')) {
            result.type = 'svg';
        }

        if(result.type === null && lElement.is('canvas')) {
            result.type = 'canvas';
        }

        if(result.type === null) {
            let computedStyle = window.getComputedStyle(hElem);
            
            if(computedStyle['backgroundImage'] != '' && computedStyle['backgroundImage'] != 'none'){
                result.type = 'background-image';
                result.src = computedStyle['backgroundImage'].slice(4, -1).replace(/"/g, "");
            }
        }     

        if(result.type === null && lElement.is('video')) {
            result.type = 'video';
        }

        //we figured something:
        if(result.type){
            if(!result.lElement){
                //just copying what we have received
                result.lElement = lElement;
            }
            //result.fullResolution = FullResolutionLocator.locate(lElement[0]);
        }
        return result;
    }

    
    /**
     * in case an element is 'inprisoned' i.e. in a div having overflow: hidden,
     * clones an element to the body so it's not cut anymore.
     * @return htmlelement : cloned element
     */
    static freeElement(elem){
        //some info:
        const bodyRect = document.body.getBoundingClientRect();
        const orygRect = elem.getBoundingClientRect();
        //copy to the body
        var clone = elem.cloneNode(true);
        clone.classList.add('inzoom-clone-freed');
        document.querySelector("body").appendChild(clone);
        clone.style.position = 'absolute';
        clone.style.left = orygRect.left + 'px';
        clone.style.top = (orygRect.top + Math.abs(bodyRect.top)) + 'px';
        return clone;
    }    
}
