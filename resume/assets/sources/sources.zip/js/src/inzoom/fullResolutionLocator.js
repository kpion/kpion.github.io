//frl - isntance of FullResolutionLocator
//returns null if this is our scope.
let locators = 
[{
    'name': 'wikimedia',
    read: (frl,callback)=>{
        let result = {};
        let src = frl.src;
        if(!frl.srcIsDomain('wikimedia.org')){
            callback(null);
            return;
        }
        let ext = null;
        if (src.substr(src.length - 8) === '.svg.png') {
            ext = '.svg';
        }
        else {
            ext = src.split('.').pop();;
        }                
        result.fullResolution = src.substring(0, src.indexOf(ext) + ext.length).replace('thumb/', '');
        callback(result)
    }
}];

/**
 * This is supposed to parse the element to get the full version (full resolution).
 * Maybe it will fetch a website or two to get it.
 */
class FullResolutionLocator {
    constructor (){
    }

    locate(elementInfo, callback){
        // logger.log('as received in locate:',elementInfo)
        this.elementInfo = elementInfo;
        this.element = elementInfo.lElement[0];
        this.src = this.elementInfo.src;
        this.documentUrl = this.element.ownerDocument.URL;
        //making the result:
        //let result = JSON.parse(JSON.stringify(elementInfo));
        let result = elementInfo;
        let curElement = this.element;
        let index = 0;
        let href = null;

        //searching for a target link, we go up.
        while (curElement != null) {
            if(curElement.tagName === 'A'){
                href = curElement.getAttribute('href');
                break;
            }
            curElement = curElement.parentElement;
            index++;
            if(index > 100){
                break;
            }
        };       
        result.href = href;
        result.fullResolution = href;//for now, we'll try better later
        // debugger;
        let locatorFound = false;
        for (var i = 0; i < locators.length; i++){
            let locator = locators[i];
            logger.log('locator:',locator);
            locator.read(this,(locResult) => {
                logger.log('l result:',locResult);
                if(locResult){
                    logger.log(`found locator "${locator.name}", full resolution found: ${locResult.fullResolution}`);
                    result.fullResolution = locResult.fullResolution;
                    locatorFound = true;
                    //callback(result);
                }
            });
            if(locatorFound){
                //the whole thing works only because everything is async anyway, but it won't be in the future.
                //break;
                break;
            }
        }
        //we didn't callback anywone above
        callback(result);
    }

    //API for the locators 'plugins'
    //not completed
    fetch (callback){
        fetch(this.url)
        .then(response => { return response.text(); })
        .then(result => {
            console.log(result);//text
            callback(result);
        });        
    }    

    //very silly but temporary. checks for the main **document** url
    documentIsDomain(test){
        return this.documentUrl.indexOf(test) !== -1;
    }
    //very silly but temporary
    srcIsDomain(test){
        return this.src.indexOf(test) !== -1;
    }
}   