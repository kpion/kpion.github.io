/**
 * Does any of the parent elements have 'overflow:hidden' or similar?
 * That, and other questions.
 * It just build an array of current and parent elements and their styles (computed styles)
 * Used when action is 'front' (bring to front)
 */
class ElementStudy {
    constructor (element = null){
        //array of: "our" element (the first one) and  then parents etc, up to the root.
        //has objects with 'computedStyle:' and later maybe others.
        this.parents = [];
        if(element){
            this.prepare(element);
        }
    }

    /**
     * 
     * 0.1ms on 100 nodes up on medium cpu. So no worries.
     */
    prepare (element){
        this.element = element;
        let curElement = element;
        let index = 0;
        while (curElement != null) {
            const info = {};
            info.element = curElement;
            info.computedStyle = getComputedStyle(curElement);
            info.index = index;
            this.parents.push(info);
            curElement = curElement.parentElement;
            
            index++;
            if(index > 100){
                break;//defensive programming ;)
            }
        };
    }

    /**
     * is any of the parent having display:hidden or anything else which hides our child directly or 
     * indirectly?
     * useful when deciding about the strategy with bringing to front.
     */
    isInprisoned(){
        console.assert(this.parents.length !== 0, 'forgot to call .prepare?');
        for (var i = 1; i < this.parents.length; i++) {
            const info = this.parents[i];
            const tagName = info.element.tagName.toLowerCase();
            //well, sometimes html has overflow: 'auto scroll' or scroll... e.g. on bing
            //but we can't do anything about it, because it's about cloning to 'body' anyway.
            if(tagName !== 'html' && tagName !== 'body'){
                if(info.computedStyle['overflow'] !== 'visible' 
                || info.computedStyle['overflow-x'] !== 'visible'
                || info.computedStyle['overflow-y'] !== 'visible'
                ){
                    return true;
                }
            }
        }
        return false;
    }
};

