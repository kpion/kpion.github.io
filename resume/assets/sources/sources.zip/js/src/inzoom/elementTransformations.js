/**
 * Zooming in / out, rotating. Used while: 
 *  - 'inline' operations (zooming in / out), context menu (both through zoomin.js -> runCommand) and also
 *  - ImageBox (the popup) when clicking the toolbar icons.
 */
class ElementTransformations {
    

    constructor (element = null){
        this.element = element;
        this.lElement = l(element);
        this.curElementOryginalStyle = Utils.getElementInlineStyle(element);
        this.curElementOryginalComputedStyle = Utils.getElementComputedStyle(element);        
        this.palette = {

            zoomIn : {
                title: 'Zoom in',
                action: 'transform',
                data: 'scale(1.4,1.4)',
            },
        
            zoomOut: {
                title: 'Zoom out',
                action: 'transform',
                data: 'scale(0.6,0.6)',
            },    
        
            rotateLeft : {
                title: 'Rotate 90° left',
                action: 'transform',
                data: 'rotate(-90deg)',
            },      
        
            rotateRight : {
                title: 'Rotate 90° right',
                action: 'transform',
                data: 'rotate(90deg)',
            },  
        
            rotate180 : {
                title: 'Rotate 180°',
                action: 'transform',
                data: 'rotate(180deg)',
            },         
            
        
        };
    }

    /**
     * 
     * @param {*} how - string, like e.g. 'rotate(90deg)'
     */
    transform(how, animate = false){
        //Animate? (Transitions)
        if(animate){
            let transitionDuration = 300;//ms
            this.lElement.css('transition-property','transform');
            this.lElement.css('transition-duration',`${transitionDuration}ms`);

            //restoring prev. style, if any
            setTimeout(()=>{
                //lElement.css('outline',this.curElementOryginalStyle['outline'] || '');
                this.lElement.css('transition-property',this.curElementOryginalStyle['transition-property'] || '');
                this.lElement.css('transition-duration',this.curElementOryginalStyle['transition-duration'] || '');
            },transitionDuration);
        }

        //let's ride
        let computedStyle = window.getComputedStyle(this.element);
        let transform = computedStyle.transform;
        if(transform === '' || transform === 'none'){
            transform = 'matrix(1,0,0,1,0,0)';
        }         
        //hmmm it seems to work o.O and no - it doesn't accumulate, it's more like recalculated.   
        //element.style.transform = transform + ` scale(${ratio},${ratio})`;
        this.element.style.transform = transform + ' ' + how;
    }
    /**
     * @param {string} which : one of 'zoomIn', 'zoomOut', 'rotateLeft' etc... listed above
     */
    transformFromPalette(which, animate = false){
        let paletteToolInfo = this.palette[which];
        if(paletteToolInfo){
            this.transform(paletteToolInfo.data, animate);
        }
    }
}