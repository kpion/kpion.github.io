"use strict";

/*
this is the inzoom core. Included by extension (in manifest.json)
as well, as can be tested standalone in any page (e.g. is used in options pages)
*/

//are we inside an extension or simply on a page as script src = '...'
let insideExtension = (
    typeof(browser) === 'object' || 
    (typeof chrome === 'object' && typeof chrome.extension === 'object'));

var logger = new Logger('inzoom: ', app.isDev());


class Inzoom{

    constructor(config){
        //are **we** inside an iframe? 
        this.insideIframe = (window.self !== window.top);

        //are **we** in an inframe and also is **user** here? with mouse pointer or otherwise. Detected thanks to mousemove and mouseout
        this.mouseInsideIframe = false;
        
        //are we top frame and some child reported they got the pointer?
        this.mouseInSomeChildIframe = true;

        //config like wheel direction, keyboard shortcuts etc.
        this.config = config;

        //recently modified element (HTMLElement)
        this.curElement = null;

        //last element *inline* style *copied* before doing anything.
        this.curElementOryginalStyle = null;

        //last element *compputed* (everything) style *copied* before doing anything.
        this.curElementOryginalComputedStyle = null;

        //recently used zindex, so... the next one in the next element selected will be higher
        this.lastZIndex = 0;

        //the very last element brought to the front by the 'front' action, really only for very 
        //temporary use
        this.lastFrontElement = null;

        //"current"  mouse position (as recorded in onMouseMove)  
        this.mousePos =  new Point();
        this.testMode = false;

        //on contextmenu event - needed when user runs a context menu command.
        this.contextMenuEvent = null;

        //this only used when double click is used as 'show box' trigger.
        this.triggerlclick = false; 
        this.triggeringlclickDone = false; 

        //a 'box', i.e. div for popup box (if enabled in options)
        // @todo - only if we're top frame, this makes sense.
        this.imageBox = new ImageBox(this.config);
        

        //
        //mouse move mode (i.e. when 'mouse move option is enabled'), currently suspended concept

        //starting point, i.e. where a user triggered this mode (i.e. by right click, if this option is enabled)
        /*
        this.mmmStartPos = new Point();
        //is mmm activated?
        this.mmmOn = false;
        //activated *and* there was an actual mouse movement, important to know if we should allow showing a context menu (if rmb mode)
        this.mmmWasMovement = false;
        this.letCtxMenuGo = true;
        */
    }

    //are we topframe?
    isTopFrame(){
        return !this.insideIframe;
    }

    isChildFrame(){
        return this.insideIframe;
    }

    //called when document ready and config loaded:
    run(){
        try{
            let hamsterTarget = document.body;
            Hamster(hamsterTarget).wheel((...params) => this.onWheel(...params));
        }catch(error){
            //the above happens really rarely, e.g. on .svg documents alone (not embedded but opened directly in browser)
            //we are catching this only to no pollute console with errors.
            return false;
        }

        document.addEventListener('mousemove', (event) => {
            this.onMouseMove(event);
        }, true); 

        document.addEventListener("mouseout", ( e ) => {   
           this.onMouseOut(e);
          }, true);

        // right now this idea is frozen
        // document.addEventListener('click', (event) => {
        //     this.onClick(event);
        // }, true);  

        // right now this idea is frozen
        // document.addEventListener('dblclick', (event) => {
        //     this.onDoubleClick(event);
        // }, true);
        
        document.addEventListener('keydown', (event) => {
            this.onKeyDown(event);
        }, true);    
        
        document.addEventListener('keyup', (event) => {
            this.onKeyUp(event);
        }, true);    

      
        //stuff related to storage changes (config) and to the contextmenu, i.e. typical to inzoom as the extension.
        if(insideExtension){
            //if config changed in storage, lets reread it.
            //btw. chrome.storage is not the same as config.storage, because the later is for example
            //chrome.storage.local
            chrome.storage.onChanged.addListener((event) => {
                //console.log('config changed for ' + window.location.href);
                this.config.clearAll(false).load();
            });

            chrome.runtime.onMessage.addListener(event => {
                this.onMessage(event);
            });                    

            //issue: context menu. In FX we need both rclick (useful when shift+rclick) and contextmenu isn't harmful here.
            //on chrome we *need* contextmenu.
            //we want to store clientX and clientY coordinates on context menu, will be useful when later user 
            //will really call a command from the context menu. Useful only when we're inside extension.
            document.addEventListener('click', (event) => {
                if(event.button === 2){
                    this.saveContextMenuEvent(event);
                }
            }, true);    

            document.addEventListener('contextmenu', (event) => {
                this.saveContextMenuEvent(event);
                //optional disabling website' context menu, which means the default one should appear.
                if(this.config.get('contextmenu.enforceDefault') && event.shiftKey){
                    event.stopPropagation();
                }
            }, true);    

        }

        /////////////////   
        //mmm - Mouse Movement Mode, i.e. user enlarge by moving mouse up / down
        //triggered by [optional, can be rmb]
        //right now - suspended, too many problems (of cours it is possible to just disable default
        //context menu behaviour, but I don't think we want it).

        /*if(this.config.get('something something')){
            this.letCtxMenuGo = false;
            document.addEventListener('mousedown', (event) => {

                if(event.button === 2){//right mouse button, rmb
                    logger.log('mmmOn');
                    this.mmmOn = true;
                    this.letCtxMenuGo = false;
                    //'offset' relative to top/left of clicked element. So if clicked at exactly topleft we'll have 0,0 here  
                    //10,0 means 10 pixels to the right
                    //offset.set(event.clientX - div.offsetLeft, event.clientY - div.offsetTop); 
                    //było offset = :
                    //x: div.offsetLeft - e.clientX,
                    //y: div.offsetTop - e.clientY
            
                    this.mmmStartPos.set(event.clientX, event.clientY);
                    event.returnValue = false;
                    event.stopPropagation();
                    event.preventDefault();
                    return false;
                }

            }, true);
        
            document.addEventListener('mousemove', (event) => {
                if (this.mmmOn) {
                    event.preventDefault();
                    this.mmmWasMovement = true;
                }
            }, true);      

            document.addEventListener('mouseup', () => {
                this.mmmOn = false;
                if(!this.mmmWasMovement){
                    this.letCtxMenuGo = true;
                }else{//there was a movement
                    this.letCtxMenuGo = false;
                }
                this.mmmWasMovement = false;
                
            }, true);

           
            document.addEventListener('contextmenu', (e) => {
                if(!this.letCtxMenuGo){
                    logger.log('ctx menu - disabling');
                    e.preventDefault();
                }
                this.letCtxMenuGo = true;//next time we surely want it.
            })        


        /////////////////
        }*/

    }
    
   
    /* 
    this function tries to find a target element (e.g. image) to zoom 
    should be an <img> or, if that cannot be found, any element with background-image, or ... 
    if that cannot be  found then IDK...
    @param  lElement - the (lightdom) element where the event (wheel, click, whatever) started.
    @param Point point : a mouse point
    @return example:
        result.type = 'img';
        result.src = <img source>;    
    **/
    findElement(lElement, point){
        //this metod will get what we understand we have in the element
        //return example:
        //{
           //type : null, //img, background-image
           //lElement : null,
        //}; 
        let result = {
            type : null, //img, background-image
            lElement : null,
        };               
        if(lElement != null){
            result = Utils.getElementInfo(lElement);
        };

        //if nothing recognized, we'll use another method 
        if(result.type === null){
            result = this.findElement2(document,point);
        }
        return result;
    }

    /* 
    we'll use current mouse pointer to find all the elements under cursor to find out 
    something which we can zoom in/out
    root at first is simply 'document', then, when going recursive, it can change into something else
    like a shadow element
    @param Document root - start node.
    @param Point point - mouse point to use in the search.
    @return example:
        result.type = 'img';
        result.src = <img source>;
    */
    findElement2(root, point){
        let result = {
            type : null, //img, background-image
            lElement : null,
        };        
        //let elements = this.elementsFromPoint(event.clientX,event.clientY);
        let elements = root.elementsFromPoint(point.x, point.y); 
        
        for (var element of elements) {
            if(typeof element.shadowRoot !== 'undefined' && element.shadowRoot){
                //console.log('found shadow!:',element.shadowRoot);
                
                result = this.findElement2(element.shadowRoot, point);
                if(result.type !== null){
                    break;
                }
            }
            result = Utils.getElementInfo(l(element));
            if(result.type !== null){
                break;
            }
        }            
        
        return result;
        
    }
    /*
    modifies element's transform:matrix - used by zoomElement
    does not seem to be needed o.O see the zoomElement 
    */
    /*
    transformElement(lElement, ratio, computedStyle = null){
        if(computedStyle === null){
           computedStyle = window.getComputedStyle(lElement[0]);
        }
        //by def. it's 'none'
        let transform = computedStyle['transform'];
        if(transform === '' || transform === 'none'){
            transform = 'matrix(1,0,0,1,0,0)';
        }
        let regex = /\((.*?),(.*?),(.*?),(.*?),(.*?),(.*?)\)/;
        let arTransform = transform.match(regex);  
        if(arTransform && arTransform.length === 7){
            arTransform.splice(0,1);
            arTransform[0] *= ratio;
            arTransform[3] *= ratio;
            let newTransform = 'matrix(' + arTransform.join(',') + ')';
            lElement.css('transform', newTransform);
            return true;
        }      
        return false;
    }
    */

    
    /**
     * this is specific to using mouse wheel, if not, then it's better to directly
     * call runCommand directly
     * 
     * elementInfo - elementInfo  to work on, Usually found with this.findElement
     * deltaY - the delta by which wheel was moved vertically   
     */ 
    zoomElement(elementInfo, deltaX, deltaY){
        //should we zoom IN or OUT
        let enlarge = null;
        if(this.config.get('zoom.wheel.direction') == 0){
            enlarge = deltaY > 0;
        }else{
            enlarge = deltaY < 0;
        }
        let ratio = enlarge ? 1.1:0.9;
        this.runCommand({
            action: 'transform',
            data: `scale(${ratio},${ratio})`,
        },elementInfo);
    }
    /**
     * 
     * deltaX - usually 0, deltaY - 0 or 1
     */
    findAndZoom(lElement, event, deltaX, deltaY){
        let found = this.findElement(lElement, new Point(event.clientX,event.clientY));
        if(found.lElement){
            this.zoomElement(found,deltaX, deltaY);
        }
    }

    /**
     * Used both by onWheel (eventually) and onContextMenu and possibly others.
     * @param {Object} command, with action and possible other properties. 
     * @param {Object} elementInfo - result of this.findElement
     */
    runCommand(command, elementInfo = null){
        //logger.log('rc:',command);
        if(command.action === 'testYourself'){
            //we are supposed to "showBox", because there was a trigger, but should we?
            //did user move over us recenty?
            if(this.insideIframe &&  this.mouseInsideIframe){
                this.showBox();
            }
            return;
        }

        if(command.action === 'infoMouseInIframe'){
            if(!this.insideIframe){
                this.mouseInSomeChildIframe = true;
                //logger.log('got info, that mouse is in an iframe');
            }
            return;
        }
        
        if(command.action === 'showBox'){
            if(command.invokeInfo && command.invokeInfo.reason === 'contextmenu'){
                this.showBox(new Point(this.contextMenuEvent.clientX,this.contextMenuEvent.clientY));
                return;
            }
            //here we don't have any 'elementInfo', we do have however something in command.data - like
            //src, type (img, video) and maybe others. which... actually is elementInfo
            //this.imageBox.create(command.data);
            this.imageBox.show(command.data);
            return;
        }

        if(command.action === 'hideBox'){
            this.imageBox.hide();
            return;
        }

        let element = null;
        if(elementInfo.lElement && elementInfo.lElement[0]) {
            elementInfo.lElement[0];
            element = elementInfo.lElement[0];
        }else{
            console.log('elementInfo is empty');
        };
        if(command.action === 'transform' && element){
            let makeDraggable = false;

            //is this the exactly same element as last time?
            let curElementChanged = (this.curElement !== element);
            this.curElement = element;
            
            if(curElementChanged){
                makeDraggable = true;
                this.curElementOryginalStyle = Utils.getElementInlineStyle(element);
                this.curElementOryginalComputedStyle = Utils.getElementComputedStyle(element);
                
            }    
            

            ///
            const elementTransformations = new ElementTransformations(element);
            //if called via context menu, we'll add some transitions.
            let animate = (command.invokeInfo && command.invokeInfo.reason === 'contextmenu');
            elementTransformations.transform(command.data,animate);
            //moving elements (dragging) 
            if(makeDraggable && this.config.get('dragging.enabled') === true){
                if(typeof element.inzoomDraggableInstance === 'undefined'){
                    element.inzoomDraggableInstance = new ElementDraggable(element);
                }
            }              
        }

        /*
        This one is in progress, there are a few issues there. 
        The idea was to display image/video url(s), as seen by inzoom, but with things inside iframes
        this opens inside this iframe. Which isn't good.  Needs more work. 
        So for now the 'properties' command is disabled in the contextmenu. 
        */
        if(command.action === 'properties' && element){
            let src = 'unknown'; 
            if(elementInfo.type === 'img'){
                src = element.getAttribute('src');
            }
            const url = new URL(src,window.location.href);
            let html = `
                <div>
                    Source: ${url.href}
                </div>
            `;
            logger.log(window.getComputedStyle(element));
            this.showModal('Inzoom element properties',html);
        }
        
        //restoring oryg style.
        if(command.action === 'reset'){
            //if it's a clone we made because of 'front' action.
            if(element && element.classList.contains('inzoom-clone-freed')){
                element.remove();
            }
            //'normal' situation
            if(element && element === this.curElement) {
                //this will revert changes made by zooming and dragging, and possibly other things 
                //(e.g. bringing to front). @todo low priority:  a list of props changed in any place and
                //here only a loop.
                this.curElement.style.transform = this.curElementOryginalStyle.transform || ''; 
                this.curElement.style.position = this.curElementOryginalStyle.position || ''; 
                this.curElement.style['z-index'] = this.curElementOryginalStyle['z-index'] || ''; 
            }
          
        }            

        //bringing the thing to front (z-index), by default on ctrl+shift+]
        if(command.action === 'front' && element){
            if(element) {
                let curElementChanged = (this.curElement !== element);
                this.curElement = element;
                if(curElementChanged){
                    this.curElementOryginalStyle = Utils.getElementInlineStyle(element);
                    this.curElementOryginalComputedStyle = Utils.getElementComputedStyle(element);
                }    
                
                const es = new ElementStudy(element);
                const isInprisoned = es.isInprisoned();
                
                //should we go with the 'clone element to body' strategy?
                const makeItFree = isInprisoned;
                if(makeItFree){
                    const freed = Utils.freeElement(element);
                    if(freed){
                        let changeZindexTo = this.lastZIndex + 1000000;
                        freed.style['z-index'] = changeZindexTo;
                        //moving elements (dragging) 
                        if(this.config.get('dragging.enabled') === true){
                            if(typeof freed.inzoomDraggableInstance === 'undefined'){
                                freed.inzoomDraggableInstance = new ElementDraggable(freed);
                            }
                        }
                        this.lastFrontElement = freed;                           
                    }
                    return;
                }
                //position (relative, absolute) - if it's oryginally 'static' we'll have to change it, because
                //z-index doesn't work on them, works only on positioned elements.
                let changePositionTo = null;
                //might later change the way we "calculate" it :)
                let changeZindexTo = this.lastZIndex + 1000000;
                const orygComputedStyle = Utils.getElementComputedStyle(element);
                if(orygComputedStyle){
                    if(orygComputedStyle.position === 'static'){
                        changePositionTo = 'relative';
                    }
                    let orygZindex = orygComputedStyle['z-index'];
                    //is it numeric? If so, then we'll change our prev. changeZindexTo:
                    if(!isNaN(parseFloat(orygZindex)) && isFinite(orygZindex)){
                        changeZindexTo = parseFloat(orygZindex) + 1000000;
                    }
                }
                this.lastZIndex = changeZindexTo;
                if(changePositionTo){
                    element.style['position'] = changePositionTo;
                }
                element.style['z-index'] = changeZindexTo;
                if(this.config.get('dragging.enabled') === true){
                    if(typeof element.inzoomDraggableInstance === 'undefined'){
                        element.inzoomDraggableInstance = new ElementDraggable(element);
                    }
                }    
                this.lastFrontElement = element;               
            }          
        }
    }

    //wheel somewhere on the page (body)
    onWheel(event, delta, deltaX, deltaY){
        //if required modifier keys do not meet keyboard status:
        //alt modifier won't work on ubuntu+kde, because alt+mouse actions are 
        //is reserved to do some tricks like moving / resizing windows (or maybe it's just 
        //my setup? IDK:))
        if((this.config.get('zoom.modifiers.ctrl') && !event.originalEvent.ctrlKey)
            || (this.config.get('zoom.modifiers.shift') && !event.originalEvent.shiftKey)
            || (this.config.get('zoom.modifiers.alt') && !event.originalEvent.altKey))
        {
            return;
        }
        event.originalEvent.preventDefault();//problem when non - passive: https://www.chromestatus.com/features/6662647093133312
        this.findAndZoom(l(event.target),event.originalEvent,deltaX,deltaY);
    }

    /**
     * Sends a 'showBox' command (which we handle here as well).
     * We do this by checking an element **under** given mouse coordinates (if null give, we'll use this.mousePos)
     * returns true if box was shown, otherwise false
     * @param {Point} mousePos - a mouse pointer or null
     * @param {Object} params - misc stuff
     */
    showBox (mousePos = null){

        logger.log('ShowBox');
        if(mousePos === null){
            mousePos = this.mousePos;
        }

        //we are top frame and plus we know the pointer is over some child frame.
        //in this case we won't try to locate the image on our frame, because it is possible that we'll find it
        //and we **don't** want it. (An issue when there is an iframe with an image, but the whole page (top frame) 
        //has a background image and this background image 'wins' with the iframe's image.)
        if(this.isTopFrame() && this.mouseInSomeChildIframe){
            //if we are top frame....
            let msg = {
                command:{
                    action: 'testYourself',
                    data: null,
                    invokeInfo: {
                        reason: 'other'
                    },
                },
            };
            this.sendMessageToTabs(msg,null,null);
            return null;
        }

        
        //let sendMsgData = {};
        let found = this.findElement(null, mousePos);
        logger.log(' found:',found);
        //did we find anything?
        if(found && found.type){
            const frl = new FullResolutionLocator();
            frl.locate(found, (elementInfoResult) => {
                //we have to clear it, otherwise we'll get “DataCloneError: The object could not be cloned.” in FireFox
                //(we're using sending messeges mechanizm)
                elementInfoResult.lElement = null;
                let msg = {
                    command:{
                        action: 'showBox',
                        data: elementInfoResult,
                        invokeInfo: {
                            reason: 'other'
                        },
                    },
                };
                this.sendMessageToTabs(msg,null,0);

            });            
            return true;            
        }  

        return false;
    }

    hideBox (){
        let msg = {
            command:{
                action: 'hideBox',
                data: null,
                invokeInfo: {
                    reason: 'other'
                },
            },
        };
        this.sendMessageToTabs(msg,null,0);        
    }

    onMouseMove(event){

        //logger.log(window.location.href);
        this.mousePos.set(event.clientX, event.clientY);
        this.lastMouseMoveEvent = event;
        if(this.insideIframe){
            if(!this.mouseInsideIframe){
                //seems like this is a mouseenter into this iframe (btw, 'normal' mouseenter does not work)
                let msg = {
                    command:{
                        action: 'infoMouseInIframe',
                        data: null,
                        invokeInfo: {
                            reason: 'other'
                        },
                    },
                };
                this.sendMessageToTabs(msg,null,null);                
            }
            this.mouseInsideIframe = true;
        }else{
            //we are 'top frame'. And since we're getting mouse input, it means mouse is over us.
            if(this.mouseInSomeChildIframe){//for the first time to be exact
                this.mouseInSomeChildIframe = false;
                //logger.log('info, mouse is on top frame');
            }
            
        }
    }
    onMouseOut(e){
        var from = e.relatedTarget || e.toElement;
        if (!from || from.nodeName == "HTML"){
            
            if(this.insideIframe){
                //logger.log('left frame');
                this.mouseInsideIframe = false;
            }else{
                //logger.log('mouseout from top frame');    
                //this.mouseInsideIframe = false;
            }
        }        
    }
    /**
     * // right now this idea is frozen
     * left click (mouse down and up) - if we want to handle double click (next method) then we have to stop
     * normal left click execution for a while.
     */
    /*
    onClick(event){
        logger.log('click',event);
        //doesn't detect ... twitter iframes.
        let eventInIframe = event.view !== window.top;
        logger.log('InIframe?',eventInIframe);
        if(eventInIframe){
            return;
        }
        //we are already inside 'click'.
        if(this.triggeringlclickDone === true){
            this.triggeringlclickDone = false;
            return;
        }
        
        logger.log('cancelling');
        //we'll simulate the trigger, unless something stops us (e.g. onDoubleClick)
        this.triggerlclick = true;
        //but for now, we'll cancelling it
        event.preventDefault();
        event.stopPropagation();

        //return;
        setTimeout(() => {
            
            this.triggeringlclickDone = true;
            //apparently onDblClick turned it off:
            if(!this.triggerlclick){
                return;
            }
            this.triggerlclick = false;
            var newEvent = new MouseEvent('click', {
                'view': window,
                'bubbles': true,
                'cancelable': true
            });
            logger.log('simulating');
            //document.dispatchEvent(event);                
            if(event.target){
                //here this is the event related to lclick.
                event.target.dispatchEvent(newEvent);
            }
        }, 400);        
    }
    */
    /*
    // right now this idea is frozen
    onDoubleClick (event){
        //logger.log('dbl click');
        this.triggerlclick = false;
        if(this.showBox(new Point(event.clientX, event.clientY))){
            //logger.log('done!');
            event.stopPropagation();
            event.preventDefault();
        }
    } 
    */  
    onKeyDown(event){
        
        //focused element
        const activeEl = event.target;// document.activeElement;

        //if user is entering text in some sort of text input then we won't do be doing .preventDefault
        let userIsTypingText = false;
        if(activeEl){
            const tagName = activeEl.tagName.toLowerCase();
            if(tagName === 'input' || tagName === 'textarea'){
                userIsTypingText = true;
            }
        }
        //'reset' action.
        //escape key
        if(event.keyCode == 27){
            this.runCommand({
                action: 'reset',
            },this.findElement(null, this.mousePos));            
        }

        
        //tests tests tests
        if(app.isDev()){
            if(event.key == '.' && event.altKey){
                console.clear();
                logger.log('dev test on',window.location.href);
                logger.log(this.isTopFrame()?'Is inside topframe':'Is inside child frame');
            }
        }

        //'front' action.
        if(
            (this.config.get('front.modifiers.ctrl') == event.ctrlKey)
            && (this.config.get('front.modifiers.shift') == event.shiftKey)
            && (this.config.get('front.modifiers.alt') == event.altKey)
            && (this.config.get('front.key') == event.keyCode)
        )   
        {
            //we'll preventDefault, but only if user isn't typing right now and 'key' is defined (we can't prevent mod keys)
            if(!userIsTypingText && this.config.get('front.key') !== 0){
                event.preventDefault();
            }
            this.runCommand({
                action: 'front',
            }, this.findElement(null, this.mousePos));            
        }  

        //'showBox' action. Mouse hover plus some keys.
        if(
            this.config.get('showBox.enabled') === true
            && this.config.get('showBox.modifiers.ctrl') == event.ctrlKey
            && this.config.get('showBox.modifiers.shift') == event.shiftKey
            && this.config.get('showBox.modifiers.alt') == event.altKey
            && (this.config.get('showBox.key') === 0 || this.config.get('showBox.key') == event.keyCode)
        )   
        {
            //logger.log('showBox shortcut...',window.location.href);
            //we'll preventDefault, but only if user isn't typing right now and 'key' is defined (we can't prevent mod keys)
            if(!userIsTypingText && this.config.get('showBox.key') !== 0){
                event.preventDefault();
            }
            if(this.imageBox.isActive()){
                this.hideBox();
            }else{
                this.showBox();
            }
        }  
    }
    onKeyUp(event){
       
    }
   
    /**
     * Creates (if needed) and shows the modal dialog.
     * 
     * @param {bool} onlyOne true: will first check if there is already one and will return that one if exists,
     *              if false: will create a new one (always).
     * @param {string} htmlcontent
     */
    /*showModal(title = '', content = '', onlyOne = true){
        logger.log('createModal');
        let elModal = document.querySelector('.inzoomModal');

        //lets create one, if needed:
        if(!onlyOne || !elModal){
            //making one:
            logger.log(' making.');
            elModal = document.createElement("div"); 
            elModal.classList.add('inzoomModal');
            document.body.insertAdjacentElement('beforeend',elModal);
        };

        //regardles if this is new or existing one, we set innerHTML to:
        elModal.innerHTML = `
            <a href="javascript:;" class="inzoomModalClose" title="Close Modal">X</a>
            <h3>${title}</h3>
            <div class="inzoomModalContent">
                ${content}
            </div>
        
        `;
        
        //this ^ means we cleared all the events, so:
        //l('.inzoomModal').classList.toggle('inzoomModalOn');
        l('.inzoomModal .inzoomModalClose').on('click',(eve)=>{
            eve.target.parentNode.classList.remove('inzoomModalOn');
        });

        //and finally - lets show it.
        elModal.classList.add('inzoomModalOn');
        return elModal; 
        
    }*/
 
    /**
     * 
     * A message sent e.g. by background.js with browser.tabs.sendMessage....
     * probably a context menu command.
     */
    onMessage(message){
        // logger.log('----------- on message -------------');
        // logger.log('  message: ', message);
        // logger.log('  href: ', window.location.href);
        if(message.command){
            /* 
            ehhh, we're a bit tricky here. We can get called for every frame on a given page separetely.
            plus, if clicked inside frame, we can get called for this one frame as well, because we're inside it as well.
            passing 'frameId:0' to chrome.tabs.sendMessage does not solve anything, because with this we don't get any
            call for the menu click anywhere. 
            */            
            if(message.command.invokeInfo){
                let invokeInfo = message.command.invokeInfo;
                let abort = false;
                if(invokeInfo.frameUrl && invokeInfo.frameUrl !== window.location.href){
                    abort = true;
                }
                if(!invokeInfo.frameUrl && (invokeInfo.pageUrl && invokeInfo.pageUrl !== window.location.href)){
                    abort = true;
                }
                if(abort){
                    //console.log(' inovocation url doesn\'t match our url, aborting');
                    return false;                    
                };   
            }
            

            if(message.command.action){//eg. 'transform'
                
                if(message.command.invokeInfo.reason === 'contextmenu'){
                    if(!this.contextMenuEvent || typeof this.contextMenuEvent.clientX === 'undefined'){
                        //for some reason we did not catch 'contextmenu' on this document ¯\_(ツ)_/¯ - probably 
                        //because there are iframes inside iframes or something...
                        logger.log('context menu command but contextMenuEvent empty');
                        return false;
                    }
                    let findResult = this.findElement2(document, new Point(this.contextMenuEvent.clientX,this.contextMenuEvent.clientY));
                    //console.log('  ctx elem:', findResult);
                    if(findResult.type){
                        this.runCommand(message.command,findResult);
                    }else{
                        logger.log('context menu command but no elemeent found');
                    }
    
                }else{//not a context menu, so e.g. we don't have anything in this.contextMenuEvent 
                    this.runCommand(message.command);
                }
            }
        }
    }

    /**
     * Sending a message around (to the background.js)
     * @param {*} param - whatever
     */
    sendMessage(message){
        chrome.runtime.sendMessage(message, function(response) {
            //btw, it seems there always is a response, even if not explicitly sent.
            if(typeof response !== 'undefined'){
                //logger.log('response',response);
            }
        });
    }

    /**
     * well, this one will ask the background process to ... send a message again to tab(s),
     * because, we can't use here (in the content script) a chrome.tabs.sendMessage () function.
     * BTW: more explanation in .local / inzoom.md
     * @param message - the message object
     * @param tabId - null means current tab. 
     * @param frameId - null means **all** the iframes, 0 means - only the main one and it's probably what we want
     * in most cases.
     * 
     */
    sendMessageToTabs(message = {}, tabId = null, frameId = null){
        //background.js will handle this one:
        this.sendMessage({please:'sendMessageToTabs',message : message, tabId : tabId, frameId : frameId});
    }
    /**
     * 
     * Fired when onClick with right mouse button, or on contextmenu event on THIS document. 
     * We need it to remember click position and maybe 
     * other things useful later when user fires a context menu command
     */
    saveContextMenuEvent(event){
        this.contextMenuEvent = {};
        //copying (only scalar props) to our contextMenuEvent
        for (var prop in event){
            if(typeof event[prop] === 'object'){
                continue;
            }
            this.contextMenuEvent[prop] = event[prop];
        }         
    };    


}


function init(){
    
    if(app.isDev()){
        //console.clear();
    }
    logger.log('init called in url:' + window.location.href);
    
    if(insideExtension){
        //on pages testing inzoom directly (via script src...) we can put in the head tag: 
        //<meta name="EnableInzoomExtension" content="false">
        //to disable the extension on these pages.
        let enableInzoomMeta =  l('meta[name="EnableInzoomExtension"]').attr('content');
        logger.log('enableInzoomMeta:',enableInzoomMeta);
        if(enableInzoomMeta === 'false' || enableInzoomMeta === '0'){
            logger.log('inzoom extension initing ABORTED, becase inside extension and EnableInzoomExtension set to false');
            return;
        }
    }
    logger.log('initing, inside extension: ', insideExtension);


    //if we are *not* inside an extension,  we'll change the default params for Config class
    let configParams = {};
    if(insideExtension){
        configParams = {
            storage : chrome.storage.local
        }        
    }else{
        configParams = {
            storage : null,//a dummy one 
            default : app.defaultConfig, //this one should come from src/common/app.js
        }
    }
    //note: config is being reread everytime user changes it in preferences.
    let config = new DotConfig(configParams);
    let iz = null;
    config.load(()=>{
        iz = new Inzoom(config);
        iz.run();
        //logger.log('Is insideIframe (' + window.location.href + ')', iz.insideIframe);
    });


}


if (document.readyState === "loading") {//might be 'loading' or 'complete'
	document.addEventListener("DOMContentLoaded", init, false);
} else {//dom already loaded (e.g. in case this script is called on document_end) so the above event will never fire, so:  
	init();
}


