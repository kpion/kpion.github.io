# About

Hi. 

There are two directories, one dedicated to PHP and includes code snippets from one of my projects. 

And then there is the 'js' directory, which includes one of my full JavaScript projects (a browser extension). 
Most important file there is src/inzoom/inzoom.js

BTW, the JS app is open sourced and is located here: https://github.com/kpion/inzoom (it's just that some recruiters want a zip file, so be it :))

---
Konrad Papała.
