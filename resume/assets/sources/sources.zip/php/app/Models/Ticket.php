<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

use App\Helpers\MyQRCode;

use Exception;
use Intervention\Image\ImageManagerStatic as Image;

class Ticket extends Model
{
    use SoftDeletes;

    public $table = 'tickets';

    protected $dates = ['deleted_at'];


    public $fillable = [
        'type',
        'product_id',
        'diploma_id',
        'comment',
        'document_params',
        'limit_count',
        'limit_dt',
        'appearance',
        'pic',
        'product_type',//regular, student, diploma etc.
        'generated_qr_code',
    ];
    
    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'type' => 'string',
        'comment' => 'string',
        'product_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    
    ];
    //e.g. generated qr codes. Relative to our 'disk', 
    //This one means: storage/app/public/qr-codes/
    const cacheDirQrCodes = 'qr-codes';


    public static function boot()
    {
        parent::boot();

        self::creating(function($model){
            //$model->hash = hash('sha256',uniqid());
            $model->hash = str_replace('.','', uniqid('', true));
            $model->product_type = 'regular';
        });
        self::created(function($model){
            
        });        
    }

    public function product()
    {
        return $this->belongsTo('App\Models\Product');
    }    
    public function diploma()
    {
        return $this->belongsTo('App\Models\Diploma');
    }    

    // public function user()
    // {
    //     return $this->belongsTo('App\User');
    // }    
    
    public function accessLog()
    {
        return $this->hasMany('App\Models\TicketAccessLog');
    }    

    /////////////////

    /**
     * utitlity - converts an array with appearance values to json
     * @param $appearance - an array with keys like backgroundColor and values like #ff0000
     * the best thing we can do is to simply name inputs like this in a form.
     * @return string or null
     */    
    public static function encodeAppearance(?array $appearance):?string{
        if($appearance){
            $appearance2 = [];
            foreach(['backgroundColor', 'foregroundColor', 'blahblahTest'] as $name){
                if(isset($appearance[$name])){
                    $appearance2[$name] = $appearance[$name];
                }
            }
            return json_encode($appearance2);
        }
        return null;
    }

    /**
     * changing appearance
     * @param $appearance - an array with keys like backgroundColor and values like #ff0000
     * the best thing we can do is to simply name inputs like this in a form.
     */
    public function setAppearance(?array $appearance){
        $this->appearance = self::encodeAppearance($appearance);
        return  $this->appearance;       
    }

    /**
     * @return an array with  e.g. [ 'backgroundColor' => '#ffffff',... ]
     */
    public static function getDefaultApperance(){
        return MyQRCode::getDefaultApperance();
    }

    /**
     * returns 'appearance' as an array with keys like backgroundColor and values like #ff0000
     * if not defined - returns an empty array or:
     * @param $defaulIfNone : if appearance is not defined for this ticket specifically,
     * then this tells to return the default settings. Otherwise an empty array.
     */
    public function getAppearance($defaulIfNone = true): array{
        if($this->appearance){
            return json_decode($this->appearance,true);
        }
        if($defaulIfNone){
            return self::getDefaultApperance();
        }
        return [];
    }

    public function setProductType($productType){
        $this->product_type = $productType;
    }

    /** 
     * the url accessed (opened in a webview) by a user when they scanned a ticket, AKA 'landing page' 
     * so, as you can see, it's handled by 'ApiController' which in turn returns a html view
     * */
    public function getAccessUrl(){

        return \URL::to("/api/access/qr/{$this->id}/$this->hash");
    }

    /**
     * new in v. 4.0 - returns SVG for direct use, it should be already there, because since 4.0 
     * we create it in the same moment the new record is created.
     */
    public function getQrCode($customParams = []){
        $result = $this->generated_qr_code;
        
        //dynamic modifications (new in 4.1)
        $defaultParams= [
            'width' => 250,
            'height' => 250,
        ];
        $params = array_merge($defaultParams, $customParams);
        $doc = new \DOMDocument;
        $doc->loadXML($result);
        $xpath = new \DOMXPath($doc);
        $xpath->registerNamespace('svg', 'http://www.w3.org/2000/svg');        

        $svgTag = $doc->getElementsByTagName('svg')[0];
        $svgTag->setAttribute('width', $params['width']);
        $svgTag->setAttribute('height', $params['height']);

        $resultModified = $doc->saveXML();        
        return $resultModified;
    }

    /**
     * creates a new qr code for this ticket. 
     * no, we don't want to do it 'on create' because we need some stuff from user input (appearance)
     */
    public function createQrCode($appearance = []){
        $this->generated_qr_code = MyQRCode::getQrCode($this->getAccessUrl(), $appearance);
        $this->save();
    }

    /**
     * Used by API to find out if for example the scan limit count is not exceeded, same with 
     * other constraints.
     * @param $hash - the hash provided by the mobile application (the one being read from qr code)
     * @param $options - an array with :
     * 
     *  ignoreInvalidHash => false/true - only useful when in demo mode. we'll pretend the hash is fine 
     *  - but not limits like 'count' etc. (useful e.g. in the  demo and links to 'samples')
     * 
     *  
     * @return array [result => number (200,404, 410), resultString => a string for a user]
     * 
     */
    public function checkAccessResult($hash, $options = []){
        $result = 200;
        $resultString = '';
        $accessLogStats = $this->getAccessLogInfo();
        $ignoreInvalidHash = $options['ignoreInvalidHash']??false;
        if(!$ignoreInvalidHash && $this->hash !== $hash){
            $result = 404;
            $resultString = 'Invalid hash';
        }else{
            if($this->limit_count !== null){
                if($accessLogStats->count >= $this->limit_count){
                    $result = 410;
                    $resultString = 'Limit count exceeded';
                }
            }
            if($this->limit_dt !== null && $this->limit_dt !== '0000-00-00 00:00:00'){
                if(time() > strtotime($this->limit_dt) ){
                    $result = 410;
                    $resultString = 'Expiration time overdue';
                }
            }                
        }   
        return [
            'result' => $result,
            'resultString' => $resultString,
        ];
    }
  
    /**
     * how many a ticket was accessed ('count') and maybe others
     */
    public function getAccessLogInfo(){
        $data = \DB::table("tickets_access_log")
        ->select(\DB::raw("COUNT(id) as count"))
        ->where('ticket_id', $this->id)
        ->first();        
        return $data;
    }

    /**
     * returns a path to student pic (owner of this ticket(diploma))
     * or null, if no pic, or the pic doesn't actually exists.
     */
    public function getStudentPicPath(){
        if(!$this->pic){
            return null;
        }

        $path = storage_path('app/protected/students-photos') . "/{$this->pic}";
        if(!file_exists($path)){
            return null;
        }
        return $path;
    }
    /**
     * true false if this guy has a photo or not
     */
    public function hasStudentPic(){
        return $this->getStudentPicPath() !== null; 
    }
    /**
     * returns a base64 of student pic (owner of this ticket(diploma))
     * or null, if no pic, or the pic doesn't actually exists.
     * The whole thing is to not keep students' photos in public place and not use it like 
     * img src = 'public place' but rather generate base64 when needed and authed.
     * @todo: maybe it's better to return a path to a photo, but this path should be a gate testing 
     * permissions.
     * @todo: if we still want base64 - we probably want to resize it to something much smaller.
     */
    public function getStudentPicBase64(){
        try{
            $path =  $this->getStudentPicPath();
            $content = file_get_contents($path);
            if($content){
                return base64_encode($content);
            }
            return null;
        }catch (\Exception $ex){
            return null;
        }
    }

    /**
     * returns a path to a thumb of student's scanned picture.
     * if there is no thumb, it will create it.
     * but if there is no main pic, then it will return null.
     */
    public function getStudentPicThumbPath(){
        $srcFilePath = $this->getStudentPicPath();
        if(empty($srcFilePath)){
            return null;
        }
        $destFilePath = storage_path('app/protected/students-photos/thumbs') . "/{$this->pic}";
        $recreate = true;
        if(file_exists($destFilePath) && filemtime($srcFilePath) <= filemtime($destFilePath)){
            $recreate = false;
        }
        if($recreate){
            try{
                $img = Image::make($srcFilePath);
                $img->resize(64, 64);
                $img->save($destFilePath); 
            }catch(\Exception $ex){
                return null;
            }
        }
        return $destFilePath;       
    }

     /**
     * returns a base64 of student pic (owner of this ticket(diploma))
     * or null, if no main pic, or the main pic doesn't actually exists.
     * The whole thing is to not keep students' photos in public place and not use it like 
     * img src = 'public place' but rather generate base64 when needed and authed.
     * @todo: maybe it's better to return a path to a photo, but this path should be a gate testing 
     * permissions.
     */    
    public function getStudentPicThumbBase64(){
        try{
            $path =  $this->getStudentPicThumbPath();
            $content = file_get_contents($path);
            if($content){
                return base64_encode($content);
            }
            return null;
        }catch (\Exception $ex){
            return null;
        }        
    }
    /**
     * For example for diplomas.
     * This parses the {param_name} strings (i.e. replaces them with a value)
     */
    public function getDocumentParsed(){
        $document_params = json_decode($this->document_params,true);
        $parsed = $this->product->document_template;
        //return $parsed;

        //this way, although simpler, has this serious problem: https://regex101.com/r/OwIxs2/1
        //it only worked by a chance, because in prevsious versions the document_params keys
        //were used in the same order as in the document itself. But in other case....

        // foreach($document_params as $paramName => $paramValue){
        //     $pattern = '~\{.*?'.$paramName.'.*?\}~i';
        //     $parsed = preg_replace($pattern, $paramValue, $parsed);
        // }
        $parsed = preg_replace_callback(
            "~\{.*?([a-z,A-Z,0-9,_]*?)}~",
            function($matches) use ($document_params){
                $paramName = $matches[1];
                if(isset($document_params[$paramName])){
                    return $document_params[$paramName];
                }
                //not in the $document_params, maybe it's some special case
                if($paramName === 'student_pic'){
                    $studentPicBase64 = $this->getStudentPicBase64();
                    if($studentPicBase64){
                        $studentPicHtml = "<img src = 'data:image/png;base64, $studentPicBase64' style = 'width:200px'/>";
                        return $studentPicHtml;
                    }
                }
                //hmm, no info for that param, we can return whatever....
                return "No value for {$paramName}";
            },
            $parsed);
        return $parsed;
    }
}
