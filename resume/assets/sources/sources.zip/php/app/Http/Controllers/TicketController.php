<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Support\Facades\Input;
use App\Http\Requests\CreateTicketRequest;
use App\Http\Requests\UpdateTicketRequest;

use App\Repositories\TicketAccessLogRepository;

use App\Repositories\TicketRepository;
use App\Http\Controllers\AppBaseController as InfyOmBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;
use Sentinel;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Session;
use App\Models\TicketAccessLog;
use App\Models\Ticket;
use App\Models\Product;
use function GuzzleHttp\json_decode;
use App\Helpers\MyQRCode;
use App\Repositories\ProductRepository;
use Illuminate\Support\Facades\URL;

use League\Csv\Reader as CsvReader;


class TicketController extends InfyOmBaseController
{
    /** @var  TicketRepository */
    private $ticketRepository;

    /** @var  TicketAccessLogRepository */
    private $ticketAccessLogRepository;

    public function __construct(TicketRepository $ticketRepo,TicketAccessLogRepository $ticketAccessLogRepo, ProductRepository $productRepo)
    {
        $this->ticketRepository = $ticketRepo;
        $this->ticketAccessLogRepository = $ticketAccessLogRepo;        
        $this->productRepository = $productRepo;
    }


    /**
     * Display a listing of Tickets.
     * ?product=<number> optional in an url
     * @return Response
     */
    public function index()
    {
        //so we can know where to come back when e.g. user clicked 'edit' or 'create'
        \App\Helpers\Utils::setBackUrl();
        $productId = Input::get('product',null);
        $product = $productId?$this->productRepository->find($productId):null;
        $tickets = $this->ticketRepository->getBy($productId, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);
        return view('admin.tickets.index', [
            'tickets' => $tickets, 
            'productId' => $productId, 
            'product' => $product
            ]);
    }

    /**
     * used by ajaxGetList and by ajaxUpdateStudentInfo (the second one so the view can be updated as well, in the right columns)
     * @return - empty string if no information.
     */
    protected function getStudentInfoString(Ticket $ticket){
        $studentString = '';
        $documentParams = $ticket->document_params?json_decode($ticket->document_params,true):null;
        //student's photo (img src = .... base64);
        $picThumbBase64 = $ticket->getStudentPicThumbBase64();
        if($picThumbBase64){
            $picThumbHtml = "<img src = 'data:image/png;base64, $picThumbBase64' style = 'width:64px'/>";
        }else{
            $noImageImageUrl = url('assets/images/autenticalia/no-image.png');
            $picThumbHtml = "<img src = '{$noImageImageUrl}' style = 'width:64px'/>";
        }
        if($documentParams){
            if(!empty($documentParams['student_name'])){
                $studentString .= "{$documentParams['student_name']}";
            }
            if(!empty($documentParams['student_email'])){
                $studentString .= " - {$documentParams['student_email']}";
            }
            if(!empty($documentParams['student_id_number'])){
                $studentString .= " - ({$documentParams['student_id_number']})";
            }
            if($studentString){
                $studentString = "$picThumbHtml <a href ='javascript:' class = 'edit-student-dlg-open'>{$studentString}</a>";
            }
        }
        return $studentString;
    }
    public function ajaxGetList(Request $request){

        //only for logging purposes
        $logInfo = [

        ];

        $requestArr =  $request->toArray();  
        $productId = Input::post('product',null);
        //$product = $productId?$this->productRepository->find($productId):null;
        $tickets = $this->ticketRepository->getBy($productId, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);
        
        // \App\Repositories\LogRepository::add('tickets::ajaxGetList, requested:',[
        //     $requestArr, 'prodid:' => $productId,
        // ],'info');         
        $dataTablesData = [];
        //@todo that is really stupid but i have only 10 minutes to complete this task
        $from = $requestArr['start'];$to = $from + $requestArr['length']-1;
        $logInfo['request-from'] = $from;
        $logInfo['to'] = $to;
        $counter = -1;
        foreach($tickets as $ticket){
            $counter ++;
            if($counter < $from || $counter > $to){
                continue;
            }
            
            $customerUrl = route('admin.users.show',$ticket->product->category->user->id );
            $accessLogUrl = route('admin.tickets.show',collect($ticket)->first() ) . "#access-log";
            $ticketShowUrl = route('admin.tickets.show',collect($ticket)->first() ) . "";
            $ticketEditUrl = route('admin.tickets.edit',collect($ticket)->first() ) . "";
            $ticketRemoveUrl = route('admin.tickets.delete',collect($ticket)->first() ) . "";
            //in case this is diplomas:
            $studentString = '';
            if($ticket->product->category->type == 'diplomas'){
                $studentString = $this->getStudentInfoString($ticket);
            }
            $dataTablesData []= [
                "<span title = 'index (one based):" . ($counter+1) ."'>{$ticket->id}</span>",
                $ticket->type,
                $ticket->comment,
                "<a href = '{$customerUrl}'>{$ticket->product->category->user->getDisplayName()}</a>",
                //this one will be empty if not a diploma type, plus will be hidden in the view.
                $studentString,
                // "{$ticket->product->name} [$ticket->product_id] in #{$ticket->product->category->name}",
                "<a href = '{$accessLogUrl}'>{$ticket->getAccessLogInfo()->count } hits</a>",
                
                //the whole 'action' column is here, with the three icons, info, edit, delete.
                "<a href='{$ticketShowUrl}'>
                    <i class='fa fa-info-circle text-primary' title='view ticket'></i>
                </a>" .

                "<a href='{$ticketEditUrl}'>
                    <i class='fa fa-pencil text-warning' title='edit ticket'></i>
                </a>" .

                "<a href='{$ticketRemoveUrl}'>
                    <i class='fa fa-trash text-danger' title='delete ticket'></i>
                </a>"

            ]; 
        }
        $logInfo['counter'] = $counter;
        $response = [
            'data' => $dataTablesData,
            'draw' => $requestArr['draw'],
            "recordsTotal" => $counter+1,//count($dataTablesData),  
            'recordsFiltered' => $counter+1,//well, it seems (in contrast to datatable specs, that his means 'filtered after any filters'. Not because of pagination)
        ];
        $logInfo ['response-recordsTotal'] = $response['recordsTotal'];
        $logInfo ['response-recordsFiltered'] = $response['recordsFiltered'];

        //\App\Repositories\LogRepository::add('TicketController::getList',$logInfo); 

        return response()->json($response);
    }

    /**
     * when in ticket list and the type is diploma - this one is going to return 
     * a html of dialog to edit student's stuff
     */
    public function ajaxGetDiplomaEditDlg (Request $request){
        $requestArr =  $request->toArray();  
        $ticketId = Input::post('ticketId',null);
        $ticket = $this->ticketRepository->findWithoutFail($ticketId);
        $html = view('admin.tickets.fields-diploma',[
            'javascriptDlg' => true,
            'document_params' => $ticket->document_params?json_decode($ticket->document_params,true):null,
        ])->render();
        $result = [
            'ticketId' => $ticketId,
            'debug' => '',
            'html' => $html,
        ];
        return response()->json($result);
    }
    
    /**
     * when in ticket list and the type is diploma - this one updates the student
     * info. Should actually be done via this->update, but... time constraints
     */
    public function ajaxUpdateStudentInfo (Request $request){
        $ticketId = $request->get('ticketId',null);
        $input = $request->all();
        if(!empty($input['document_params'])){
            $input['document_params'] = json_encode($input['document_params']);
        }
        $ticket = $this->ticketRepository->update($input, $ticketId);
        $result = [
            'ticketId' => $ticketId,
            'debug' => '',
            'error' => 0,
            //this is is here, so the html table row/column can be updated (e.g. students name)
            'studentInfoString' => $this->getStudentInfoString($ticket),
        ];
        return response()->json($result);
    }

    /**
     * Display a listing of Tickets -> qr codes in printable format.
     *
     * @return Response
     */
    public function indexPrintable()
    {
        $productId = Input::get('product',null);
        $product = $productId?$this->productRepository->find($productId):null;
        $tickets = $this->ticketRepository->getBy($productId, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);
        return view('admin.tickets.index-printable', ['tickets' => $tickets, 'productId' => $productId]);
    }

     /**
     * Display AS PDF, a listing of Tickets
     *
     * @return Response
     */
    public function indexPdf()
    {
        app('debugbar')->disable();
        $tmpPath  = Storage::disk('local')->getDriver()->getAdapter()->getPathPrefix();
        $tmpPath .= 'protected/tmp';
        $mpdf = new \Mpdf\Mpdf([
            'tempDir' => $tmpPath,
            'default_font_size' => 8,
            ]);
        $mpdf->showImageErrors = true;
        //$mpdf->WriteHTML('<h1>Hello world!</h1>');
        $productId = Input::get('product',null);
        $product = $productId?$this->productRepository->find($productId):null;
        $tickets = $this->ticketRepository->getBy($productId, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);
        $html = view('admin.tickets.index-pdf', 
            [
                'tickets' => $tickets, 
                'productId' => $productId,
                'width' => Input::get('width',128),
                'height' => Input::get('height',128),
                'oneColumn' => Input::get('oneColumn',false), 
                'includeStudentIdNumber' => Input::get('includeStudentIdNumber',false), 
                'includeStudentName' => Input::get('includeStudentName',false), 
            ]
        )->render();
        
        $mpdf->WriteHTML($html);
        //$mpdf->WriteHTML('<h1>Hello world!</h1>');
        if(Input::get('download') === 'yes'){
        $mpdf->Output('export.pdf',\Mpdf\Output\Destination::DOWNLOAD);    
            return;
        }else{
            $mpdf->Output();
        }
    }

    /**
     * Exporting to pdf
     */
    public function export(Request $request){
        $productId = Input::get('product',null);
        $size = Input::get('size',128);
        
        $product = $productId?$this->productRepository->find($productId):null;
        if(Input::get('submit')){
            //$redirUrl = route('admin.tickets.index.pdf')."?product={$productId}&width={$width}&height={$height}";
            //redirect('admin.tickets.index.pdf');return;
            //dump(Input::get('oneColumn',false));die('aaa');
            return redirect()->action('TicketController@indexPdf',[
                'product' => $productId,
                'width' => $size,
                'height' => $size,
                'download' => 'yes',
                'oneColumn' => Input::get('oneColumn',false),
                'includeStudentIdNumber'=> Input::get('includeStudentIdNumber'),
                'includeStudentName'=> Input::get('includeStudentName',false),
            ]);
            //redirect($redirUrl);
            
        }
        //$products = Product::All()->pluck('name','id');
        return view('admin.tickets.export',[
            'productId' => $productId,
        ]);        
    }

    /**
     * Display the specified Ticket.
     * @todo - bug: nonadmin can see any ticket by entering the id in url
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $ticket = $this->ticketRepository->findWithoutFail($id);
        
        if (empty($ticket)) {
            Flash::error('Ticket not found');
            return redirect()->back();
        }
        /*$accessLog = $this->ticketAccessLogRepository->findWhere([
            'ticket_id' => $ticket->id,
        ]);*/
        
        return view('admin.tickets.show')
            ->with('ticket', $ticket)
            ->with('document_params',$ticket->document_params?json_decode($ticket->document_params,true):null);
    }

    /**
     * OLD: now lets just use the API.
     * This is more for debugging and testing.
     * It displays the same view as an end user will see after scanning.
     * @param $endUserId : the user who scanned the ticket.
     */
    // public function showAccess($id, $endUserId = null)
    // {
    //     $ticket = $this->ticketRepository->findWithoutFail($id);
        
    //     if (empty($ticket)) {
    //         Flash::error('Ticket not found');
    //         return redirect()->back();
    //     }

    //     $resultInfo = $ticket->checkAccessResult($ticket->hash);
    //     $result = $resultInfo['result'];
    //     $resultString = $resultInfo['resultString'];
    //     $viewData  = [
    //         'result' => $result, 
    //         'resultString' => $resultString,
    //         'ticket' => $ticket,
    //     ];
    //     if($ticket->product->category->type === 'diplomas'){
    //         $viewData['document_params'] = $ticket->document_params?json_decode($ticket->document_params,true):null;
    //         return view('api.access-regular-diploma',$viewData);
    //     }
    //     return view('api.access-regular',$viewData);
            
    // }
    
    /**
     * Show the form for creating new Ticket(s).
     * Optional ?product=<number> in url
     * @todo - bug: nonadmin can see all products and create a ticket under any product
     * @return Response
     */
    public function create()
    {
        if(Input::get('mobile')){
            app('debugbar')->disable();
        }        
        $productId = Input::get('product',null);
        $requestedProduct = $productId?$this->productRepository->find($productId):null;

        $products = Product::All()->pluck('name','id');
        return view('admin.tickets.create',[
            'products' => $products,
            'productId' => $productId,
            'requestedProduct' => $requestedProduct,
            'appearance' => Ticket::getDefaultApperance(),
        ]);
    }

    /**
     * Store a newly created Ticket in storage.
     * @todo - bug: nonadmin can create tickets under any product
     * @param CreateTicketRequest $request
     *
     * @return Response
     */
    // public function store(CreateTicketRequest $request)
    // {
    //     $input = $request->all();
    //     if(!empty($input['limit_dt'])){
    //         $input['limit_dt'] = date($input['limit_dt']) . ' 23:59:59';
    //     }
    //     //$input = $request->only(['type', 'comment', 'product_id']);
    //     $quantity = $request->input('quantity',1);
        
    //     $input['appearance'] = Ticket::encodeAppearance($input);
    //     for ($n = 0; $n < $quantity; $n++){
    //         $ticket = $this->ticketRepository->create($input);
    //     }
    //     Flash::success('Ticket saved successfully :' . $input['qr-codes-generated-name']);
    //     //return redirect(route('admin.tickets.index',[$request->input ('product_id',null)]));
    //     return redirect(route('admin.tickets.index')."?product={$input['product_id']}");
        
    // }

  

    /**
     * Show the form for editing the specified Ticket.
     * @todo - bug: nonadmin can edit any ticket
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        if(Input::get('mobile')){
            app('debugbar')->disable();
        }
        //die('@todo - implement editing');
        $ticket = $this->ticketRepository->findWithoutFail($id);

        if (empty($ticket)) {
            Flash::error('Ticket not found');
            return redirect(route('tickets.index'));
        }
        $products = Product::All()->pluck('name','id');
        return view('admin.tickets.edit')
            ->with('ticket', $ticket)
            ->with('document_params',$ticket->document_params?json_decode($ticket->document_params,true):null)
            ->with('products',$products)
            ->with('appearance',$ticket->getAppearance())
        ;
    }

    /**
     * Update the specified Ticket in storage.
     * used when editing, because when creating we use ajaxGenerateAll
     * @todo - bug: nonadmin can edit any ticket
     * @param  int              $id
     * @param UpdateTicketRequest $request
     *
     * @return Response
     */
    public function update($id = null, UpdateTicketRequest $request)
    {
        $ticket = $this->ticketRepository->findWithoutFail($id);

        if (empty($ticket)) {
            Flash::error('Ticket not found');
            return redirect(route('tickets.index'));
        }
        $input = $request->all();
        if(!empty($input['limit_dt'])){
            $input['limit_dt'] = date($input['limit_dt']) . ' 23:59:59';
        }
        $input['appearance'] = Ticket::encodeAppearance($input);
        if(!empty($input['document_params'])){
            $input['document_params'] = json_encode($input['document_params']);
        }
        //upload image
        if ($file = $request->file('pic'))
        {
            // $fileName        = $file->getClientOriginalName();
            // @todo a hacker can actually upload anything .....
            $extension       = $file->getClientOriginalExtension() ?: 'png';
            //$folderName      = '/uploads/products/';
            //$destinationPath = public_path() . $folderName;
            $safeName        = $id.'.'.$extension;
            $destinationDir = storage_path('app/protected/students-photos');
            $file->move($destinationDir, $safeName);
        }
        if($request->get('pic-remove') === 'true'){
            $input['pic'] = null;
        }else{
            $input['pic'] = isset($safeName)?$safeName:'';
        }
        $ticket = $this->ticketRepository->update($input, $id);
        //since the appearance could have changed.... eeee, no it could not in new version.
        //$ticket->removeCachedQrCode();
        Flash::success('Ticket updated successfully.');
        //return redirect(route('admin.tickets.index'));
        
        return redirect()->to(\App\Helpers\Utils::getBackUrl());
    }

    /**
     * Remove the specified Ticket from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function getModalDelete($id = null)
    {
        $error = '';
        $model = '';
        $confirm_route =  route('admin.tickets.delete',['id'=>$id]);
        return View('admin.layouts/modal_confirmation', compact('error','model', 'confirm_route'));

    }

    public function getDelete($id = null)
    {
        $sample = Ticket::destroy($id);

        // Redirect to the group management page
        return redirect(route('admin.tickets.index'))->with('success', Lang::get('message.success.delete'));
    }

    /**
     * Only for 'diplomas' (category type)
     * Inserting ONE student. 
     * we expect here to have an array of data with keys like:
     *  student_name, student_email, student_id_number, comment
     */
    protected function importStudent(array $oneStudent, $productId){
        $commnent = '';
        if(isset($oneStudent['comment'])){
            $commnent = $oneStudent['comment'];
            //this goes to ticket comment, we don't want to have it here too
            unset ($oneStudent['comment']);
        }        
        $ticket = [
            'product_id' => $productId,
            //created_at
            //updated_at
            'deleted_at' => NULL,
            'type' => 'qr',
            //hash (created by repo)
            'comment' => $commnent,
            //appearance
            //generated_qr_code
            'limit_count' => null,
            'limit_dt' => null,            
            'document_params' => json_encode($oneStudent),
        ];
       
        $this->ticketRepository->create($ticket);
    }
    /**
     * Importing from csv file
     * Both showing a form and the action
     */
    public function import(Request $request){
        $productId = Input::get('product',null);//it's in url
        assert($productId);
        $product = $productId?$this->productRepository->find($productId):null;
        
        if(Input::post('submit')){
            //upload image
            if ($file = $request->file('file'))
            {
                //load the CSV document from a file path
                $csv = CsvReader::createFromPath($file->path(), 'r');
                $csv->setHeaderOffset(0);
                $header = $csv->getHeader(); //returns the CSV header record
                if(!in_array('student_name',$header) && !in_array('student_id_number',$header)){
                    Session::flash('error', 'One of those fields is required: student_name or student_id_number, none of them is');
                    return redirect()->back();
                }
                $records = $csv->getRecords(); //returns all the CSV records as an Iterator object
                $successCount = 0;
                foreach($records as $record){
                    $this->importStudent($record,$productId);
                    $successCount++;
                }
                //Session::flash('message', "$successCount students (tickets) imported successfully");
                Session::flash('success', "$successCount students (tickets) imported successfully");
                //Flash::message("$successCount students (tickets) imported successfully");
            }else{
                Session::flash('error', 'No file specified');
            }

            return redirect()->back();//yeah, it should be here.
        }
        
        return view('admin.tickets.import',[
            'product' => $product,
        ]);        

    }

    /**
     * 
     * New version: Called via ajax on editing/creating ticket.
     * expected (in POST) - backgroundColor, foregroundColor and maybe others.* 
     * @TODO: this one should be refactored to use the same methods as ajaxGenerateAll
     * We don't need to to play with files. 
     */
    public function ajaxGetQRCodePreviewNew(Request $request){
        $curUser = Sentinel::getUser();
        $storagePath  = Storage::disk('local')->getDriver()->getAdapter()->getPathPrefix();
        $storagePath .= 'public/qr-codes';
        $dirUrl = \URL::to('/storage/qr-codes');
        $fileName = hash('sha256',$curUser['id']);//it's really not important what the name is
        return response()->json(MyQRCode::processAjaxRequest($storagePath,$dirUrl, $fileName));
    }    

    //generating all tickets (as many as selected)
    public function ajaxGenerateAll(Request $request){
        $input = $request->all();
        // $storagePath  = Storage::disk('local')->getDriver()->getAdapter()->getPathPrefix();
        // $storagePath .= 'public/qr-codes';
        // $dirUrl = \URL::to('/storage/qr-codes');

        if(!empty($input['limit_dt'])){
            $input['limit_dt'] = date($input['limit_dt']) . ' 23:59:59';
        }
        
        $quantity = $request->input('quantity',1);
        
        if(!empty($input['document_params'])){
            $input['document_params'] = json_encode($input['document_params']);
        }
        for ($n = 0; $n < $quantity; $n++){
            $ticket = $this->ticketRepository->create($input);
            //$fileName = $ticket->getFileNameSuggestion();
            //$accessUrl = $ticket->getAccessUrl();
            //$response = MyQRCode::processAjaxRequest($storagePath,$dirUrl, $fileName, $accessUrl);
            $ticket->createQrCode($input);
        }
        Flash::success('Ticket saved successfully :');
        return redirect(route('admin.tickets.index')."?product={$input['product_id']}");
        
    }
    /**
     * not used anymore.
     * displays specific access log details (one hit)
     * includes google maps and other user data.
     * later it will be probably moved to ajax on the ticket.show page.
     */
    public function logItem($logItemId){
        $logItem = $this->ticketAccessLogRepository->findWithoutFail($logItemId);
        
        if (empty($logItem)) {
            Flash::error('Access log hit not found');
            return redirect(route('tickets.index'));
        }
        /*$accessLog = $this->ticketAccessLogRepository->findWhere([
            'ticket_id' => $ticket->id,
        ]);*/
        return view('admin.tickets.log_item')->with('logItem', $logItem);
    }
}
