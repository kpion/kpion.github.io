<?php

namespace App\Repositories;

use App\Models\Diploma;
use InfyOm\Generator\Common\BaseRepository;

class DiplomaRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return Diploma::class;
    }

    /**
     * Joins stuff and returns result.
     * We can specify both categoryId and userId (studentId) or one of them or none.
     */
    public function getBy($schoolId = null, $studentId = null){
        
        $diplomas = Diploma
        ::select(['diplomas.*']);
        //->join('categories','diplomas.category_id', '=', 'categories.id');

        // if($schoolId !== null){
        //     $diplomas->where('users.id', $schoolId);
        // };

        // if($studentId !== null){
        //     $diplomas->where('users.id', $studentId);
        // };

        return $diplomas->get();        

    }    
}
