<?php

namespace App\Repositories;

use Illuminate\Support\Facades\DB;
use App\Models\Ticket;
use App\Models\TicketAccessLog;

use InfyOm\Generator\Common\BaseRepository;

class TicketAccessLogRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return TicketAccessLog::class;
    }

    /**
     * used by the getRecent, getByTickets etc family functions 
     */
    protected function buildWhere($conditions){
        $result = [
            'whereAccLog' => '',//where ... inside the ...from tickets_access_log sub query
        ];
        if(!empty($conditions['dateFrom'])){
            if($conditions['dateFrom'] instanceof \DateTime){
                $conditions['dateFrom'] = $conditions['dateFrom']->format('Y-m-d H:i:s');
            }
            $result['whereAccLog'] .= "where tickets_access_log.dt >= '{$conditions['dateFrom']}'";
        }
        if(!empty($conditions['dateTo'])){
            if($conditions['dateTo'] instanceof \DateTime){
                $conditions['dateTo'] = $conditions['dateTo']->format('Y-m-d H:i:s');
            }            
            $result['whereAccLog'] .= "where tickets_access_log.dt <= '{$conditions['dateTo']}'";
        }
        return $result;
    }
 

    /**
     * @return array of stdClass,
     * nothing interesting exept it returns data in similar fashion to the ->getByProduct etc methods below
     * so this can be also used like them - e.g. in the dashboard / feeed
     * @param $customerId - customer user id, i.e. owner of category 
     */
    public function getRecent(int $limit = 10, int $customerId = null, $conditions = []){
        

        $whereCustomer = '';
        if($customerId !== null){
            $whereCustomer = "where u.id = $customerId";
        }
        //other where:
        $where = $this->buildWhere($conditions);
        $sql = "
            select 
                
            p.id prod_id, p.name prod_name, 
            u.first_name cust_first_name, u.last_name cust_last_name, # customer
            acc_log.dt access_dt, DATE_FORMAT(acc_log.dt,'%H:%i:%s') access_dt_time, acc_log.user_id as end_user_id # end user

            from (
                select ticket_id, dt, result, user_id
                from tickets_access_log 
                {$where['whereAccLog']}
                
            ) as acc_log

            join tickets as t on acc_log.ticket_id = t.id
            join products as p on t.product_id = p.id
            join categories as c on p.category_id = c.id
            join users as u on c.user_id = u.id
            
            $whereCustomer   

            order by acc_log.dt desc        
            limit $limit
        ";
        return \DB::select(\DB::raw($sql));
    }
    /** 
    * @return array of stdClass, - most popular tickets by number of accesses.
    * for exampled the 'id' field is the ticket's id, and so on.
    */
    public function getByTickets(){

        $sql = "select final.*, sum(acc_log.accesses) accesses_total # sum() not really needed for consistency with the others
        from (
            select ticket_id, count(*) as accesses
            from tickets_access_log 
            group by tickets_access_log.ticket_id
        ) as acc_log
        join tickets as final on acc_log.ticket_id = final.id
        group by final.id # not really needed for consistency with the others
        order by acc_log.accesses desc;";
        return \DB::select( \DB::raw($sql));
    }

    /** 
    * @return array of stdClass, - most popular products by number of accesses.
    * for exampled the 'id' field is the product's id, and so on.
    */
    public function getByProducts(){
        $sql = "
        select final.*, sum(acc_log.accesses) as accesses_total
        from (
            select ticket_id, count(*) as accesses
            from tickets_access_log 
            group by tickets_access_log.ticket_id
        ) as acc_log
        join tickets as t on acc_log.ticket_id = t.id
        join products as final on t.product_id = final.id
        group by final.id
        order by accesses_total desc;";
        return \DB::select( \DB::raw($sql));
    }

    /** 
    * @return array of stdClass, - most popular users (i.e. customers, i.e. category owners) 
    * by number of accesses.
    * for exampled the 'id' field is the user's id, and so on.
    */
    public function getByCustomers(){
        $sql = "
        select final.*, sum(acc_log.accesses) as accesses_total
        from (
            select ticket_id, count(*) as accesses
            from tickets_access_log 
            group by tickets_access_log.ticket_id
        ) as acc_log

        join tickets as t on acc_log.ticket_id = t.id
        join products as p on t.product_id = p.id
        join categories as c on p.category_id = c.id
        join users as final on c.user_id = final.id

        group by final.id
        order by accesses_total desc

        ";        
        return \DB::select( \DB::raw($sql));
    }

    /** 
    * @return array of stdClass, - most popular countries
    * by number of accesses.
    * for example the 'id' field is the country id in 'countries'
    */
    public function getByCountries(){

        /*$sql = "
        select final.*, sum(acc_log.accesses) as accesses_total
        from (
            select country_code, ticket_id, count(*) as accesses
            from tickets_access_log 
            # group by tickets_access_log.ticket_id
            group by tickets_access_log.country_code
        ) as acc_log

        join geo_countries as final on acc_log.country_code = final.country_code

        group by final.id
        order by accesses_total desc
        ";*/        
        $sql = "
            select final.country_name as name, final.*, count(tickets_access_log.id) as accesses_total
            from tickets_access_log 
            join geo_countries as final on tickets_access_log.country_code = final.country_code
            group by tickets_access_log.country_code, final.id
            order by accesses_total DESC,name
        ";

        return \DB::select( \DB::raw($sql));
    }    

    /** 
    * @return array of stdClass, - most popular continents
    * by number of accesses.
    * for example the 'id' field is the continent id in 'continents'
    */
    public function getByContinents(){
        $sql = "
            select final.continent_name as name, final.*, count(tickets_access_log.id) as accesses_total
            from tickets_access_log 
            join geo_countries on tickets_access_log.country_code = geo_countries.country_code
            join geo_continents as final on geo_countries.continent_code = final.continent_code
            group by final.id
            order by accesses_total DESC,name
        ";        
        return \DB::select( \DB::raw($sql));
    }    

    /** 
    * @return array of stdClass, - most popular os (operating systems)
    * by number of accesses.
    */
    public function getByOss(){

     
        $sql = "
            select final.user_client_os as user_client_os, count(final.id) as accesses_total
            from tickets_access_log as final
            group by final.user_client_os
            order by accesses_total DESC,user_client_os
        ";

        return \DB::select( \DB::raw($sql));
    }    

    /** 
    * @return array of stdClass, - most popular browser
    * by number of accesses.
    */
    public function getByBrowsers(){

     
        $sql = "
            select final.user_client_browser as user_client_browser, count(final.id) as accesses_total
            from tickets_access_log as final
            group by final.user_client_browser
            order by accesses_total DESC,user_client_browser
        ";

        return \DB::select( \DB::raw($sql));
    }    

}
