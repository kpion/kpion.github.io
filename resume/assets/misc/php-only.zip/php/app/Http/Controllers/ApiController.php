<?php

namespace App\Http\Controllers;

/**
 * Used by the mobile application. 
 * But also by the website - to get some stats data (on the admin dasbhoard)
*/
use GuzzleHttp\Client;
use File;
use Sentinel;
use Illuminate\Support\Arr;
use App\Http\Requests;

use App\Repositories\TicketAccessLogRepository;
use App\Models\TicketAccessLog;

use App\Repositories\TicketRepository;
use App\Http\Controllers\AppBaseController as InfyOmBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use App\Models\Ticket;
use App\Models\Product;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;
use Illuminate\Support\Facades\Input;
use function GuzzleHttp\json_encode;
use Illuminate\Support\Facades\App;
use Symfony\Component\Console\Helper\Helper;
use App\Helpers\Geocoding;

use Illuminate\Support\Facades\Storage;

class ApiController extends ChandraController
{
    /** @var  TicketRepository */
    private $ticketRepository;

    /** @var  TicketAccessLogRepository */
    private $ticketAccessLogRepository;

    //for testing:
    const fakeFbUser = [
        'id' => 12345678,
        'name' => 'John Smith',
        'first_name' => 'John',
        'last_name' => 'Smith',
        'link' => 'https://www.facebook.com/app_scoped_user_id/YXNpZADpBWEZAUanByOURyNGlOVEl1S21tS3YzVU14UGhaT0lfMldNMmNlb0ttLVNXWU55U3NxQ2szdktLUXJmYVlnc2J5aXB3SnN0UHJuQU9TZAkV0d1pZAMzN1elFDUXJDUEUtNTl1WGZAQcnJwZADJfQ3dEQlNj/',
        'picture' => [],

        'gender' => 'male',
        'email' => 'blah2@example.com',
        'birthday' => '10/30/1999',
        'location' => [
            'id' => 102187606489097,
            'name' => 'Bydgoszcz, Poland',

        ],
        'friends' => [
            
                'data' => [],
                'summary' => [
                        'total_count' => 2
                ]    
        ]
    ];

    public function __construct(TicketRepository $ticketRepo,TicketAccessLogRepository $ticketAccessLogRepo)
    {
        $this->ticketRepository = $ticketRepo;
        $this->ticketAccessLogRepository = $ticketAccessLogRepo;        
    }


    /**
    *  Scan. *Yes* this one, by default, returns a HTML webpage. A 'landing page'.
    *  This is what a qr scanner (e.g. in mobile app) accesses, i.e. a page being *opened*
    *  in webview, AKA 'landing page' 
    *  
    *  But *also* can be used to just get a landing page, without any concequences for preview
    *  purposes (in the admin panel), and *also*, since we can change the output type, we can actually
    *  get not only a "page" but e.g. a json. 

    *  This is also used for testing purposes, i.e. by mobile apps to e.g. get any Diploma ticket's id
    *  Here we do a check if this is our url and hash is correct etc.
    *  
    * @param $type e.g. 'qr' or 'qr-student'
    * @param $id - ticket's id. In case of testing and debugging this can also be a string: 
    *   'auto-generic' - this will 'access' very first ticket among the 'generic' tickets
    *   'auto-diploma' - this will 'access' very first ticket among the 'diploma' tickets
    * @param $hash - just for confirmation
    * @param $userID - this one is added *only* (in theory) by the mobile app. by the chequo app.
    * 
    * Right now it's enough that this will be non empty, but @todo : some kind of auth here.
    * 
    * Also URL get params: 
    * example url: api/access/qr/1/444somehash4444?previewOnly=true&ignoreInvalidHash=true&mobile=true
    * 
    * Params:
    * type - is it qr code or something else (in the future)
    * lat, lng : latitude and longitude
    * 
    * output=html/json - by default 'html' and when in demo mode:
    *   qr-code: a single **image** of the qr code 
    *   id: just an id
    *   hash: just a hash
    * 
    * mobile = false/true - if true, we'll pretend that a mobile app did that, even if userId is empty
    *  (because if it's not empty, then it's the mobile app by definition)
    * 
    * previewOnly=false/true - if true:
    *  no stats will be updated, no 'access log' is inserted,
    *  useful when showing a preiew only in the admin panel.
    * 
    * ignoreInvalidHash=false/true - only when in demo mode. we'll pretend the hash is fine (usefull e.g. in the 
    * demo and links to 'samples')
    
    * @return Response
    */
    public function access(?string $type = null, $ticketId = null, ?string $hash = null, $userId = null)
    {
        app('debugbar')->disable();
        $isDemo = (env('APP_DEMO') === true);
        //returning docs
        if($type === null && $isDemo){
            return view('api.access-help');
        }

        //client info (if any)
        $userAgentInfo = \App\Helpers\Utils::getUserAgentInfo();
        $clientIp = \App\Helpers\Utils::getClientIp();

        //urls params
        $lat = Input::get('lat', null);
        $lng = Input::get('lng', null);
        $output = Input::get('output', 'html');//html/json
        $mobile = Input::get('mobile', false) === 'true';//true/false
        
        $previewOnly = Input::get('previewOnly', false);//true/false, only preview, don't update any stats
        $ignoreInvalidHash = Input::get('ignoreInvalidHash', false) === 'true';//true/false - if true, we won't check the hash
        
        $dbgLogTitle = 'api::access';
        if($output === 'html' || $output === 'json'){
            $dbgLogTitle .= ' (probably scan)';
        }else{
            $dbgLogTitle .= ' (probably fetching some info)';
        }
        \App\Repositories\LogRepository::add($dbgLogTitle,[
            'type' => $type, 'ticketId' => $ticketId, 'userId' => $userId, 'previewOnly' => $previewOnly,
            'output' => $output
        ],'info','api'); 
        $ticket = null;
        if($isDemo){
            //here we allow some tricks, like getting the very first diploma ticket, for the Plato app to make tests
            if($ticketId === 'auto-generic'){
                $ticket = $this->ticketRepository->getBy(1,null)[0];
            }elseif($ticketId === 'auto-diploma'){
                //we know this product (11) is a diploma type, because this is what populator (in simulator) does
                $ticket = $this->ticketRepository->getBy(11,null)[0];
            }
        }
        //still nothing? we expect $ticketId to be a simple (int)id, not some debug/test trick.
        if($ticket === null){
            $ticket = $this->ticketRepository->findWithoutFail($ticketId);
        }

        $accessLogEntry = null;
        
        $resultCode = 200;//for starters. 
        $resultString = '';//more for debug purposes.
        
        if(empty($ticket)){
            $resultCode = 404;
            $resultString = 'No such ticket';
        }else{
            $resultInfo = $ticket->checkAccessResult($hash,[
                'ignoreInvalidHash' => $ignoreInvalidHash && $isDemo,
            ]);
            $resultCode = $resultInfo['result'];
            $resultString = $resultInfo['resultString'];
            if(!$previewOnly){//it is NOT a preview only, but rather a real access(scan)
                //access log.
                $accessLogEntry = [
                    'dt' => date('Y-m-d H:i:s'),
                    'ticket_id' => $ticketId,
                    'user_id' => $userId,
                    'lat' => $lat,
                    'lng' => $lng,
                    'user_client_ip' => $clientIp,
                    'user_client_os' => $userAgentInfo['platform'] ?? null,
                    'user_client_browser' => $userAgentInfo['name'] ?? null,
                ];
                //country...
                $geo = new \App\Helpers\Geocoding();
                $info = $geo->getCountry($lat,$lng);         
                $accessLogEntry['country_code'] = $info['country_code'];
                //result...    
                $accessLogEntry['result']  = $resultCode;

                $this->ticketAccessLogRepository->create($accessLogEntry);
            }
        }
        //displaying the result
        $isDiploma = false;
        // if($ticket && $ticket->product && $ticket->product->category->type === 'diplomas'){
        //     $isDiploma = true;
        // }
        if($ticket && $ticket->diploma_id){
            $isDiploma = true;
        }
        $documentParams = null;//only if diplomas type
        if($ticket->document_params){
            $documentParams = json_decode($ticket->document_params,true);
        }
        $viewData  = [
            'result' => $resultCode, 
            'resultString' => $resultString,
            'ticket' => $ticket,
            'access_log' => $accessLogEntry,
            '$isDiploma' => $isDiploma,
            'documentParams' => $documentParams,//only if diplomas type,
            'diploma' => $ticket->diploma??null,
            'mobile' => $mobile,
        ];
        //dump($viewData);die();
        if($output === 'html'){
            
            $viewFile = 'api.access';
            //chequo user, on a mobile, or forcing mobile by a flag in url.
            // if($userId  || $mobile){
            //     return view('api.access', $viewData);
            // }else{//non chequo user
            //     return view('api.access-regular', $viewData);
            // }
            if(!$userId && !$mobile){
                $viewFile .= '-regular';
            };
            if($isDiploma){
                $viewFile .= '-diploma';
            };
            return view($viewFile, $viewData);
        }elseif ($output === 'json'){
            
            return response()->json([
                'result' => $resultCode,
                'resultString' => $resultString,
                'documentParams' => $documentParams,
            ]);
        };
        //if we'are still here, it's probably some 'sample' for the debug / tests purposes by mobile apps.
        //and it's probably just a simple string, no need for views etc. 
        $content = '';
        $contentType = 'text/plain';
        //image only
        if($output === null || $output === 'qr-code'){
            //$contentType = 'image/png';
            $imgUrl = $ticket->getQRCodeUrl();
            if($imgUrl){
                $content = file_get_contents($imgUrl);
                $contentType = 'image/png';
            }else{
                $content = 'image not found o.O';
            }
        //hash only
        }elseif ($output === 'hash'){
            $content = $ticket->hash;
        }elseif ($output === 'id'){
            $content = $ticket->id;
        }elseif ($output === 'student'){
            $content = $ticket->id;
        }else{
            throw new \Exception('wrong "$output" parameter');
        }
        return response($content)->header('Content-Type', $contentType);        
    }

    /**
     * End user started the app. We actually don't do anything with it yet,
     * it's only for testing purposes.
     * In the request we expect user data (if any)
     */ 
    // public function onAppStart(Request $request){
    //     $requestArr =  $request->toArray();   
    //     \App\Repositories\LogRepository::add('api::onAppStart',$requestArr);    
    //     $response = [
    //         'debug' => 'test',
    //     ];
    //     return response()->json($response);
    // }
    
    /**
     * A log info from mobile application. Only for debugging purposes.
     * p.s. added to app/Http/Middleware/VerifyCsrfToken.php so no token needed.
     */
    public function mobileAppLog(Request $request){
        $requestArr =  $request->toArray();   
        $source = 'mobile';
        $message = $requestArr['message'] ?? '[no message]';
        $level = $requestArr['level'] ?? 'info';
        \App\Repositories\LogRepository::add($message, $requestArr['data'] ?? null, $level, $source);    
        $response = [
            'result' => 'ok',
        ];
        return response()->json($response);
    }
    /**
     * Update or insert a ticket. Depends on post params. 
     * Used by Plato app, when uploading a photo (a photo of student's identif. card)
     * And when the app does this, it can be a new ticket (student/diploma), or an existing one (thanks
     * to scanning a ticket's qr code from the screen having a  web app running)
     */
    public function upsertTicket(Request $request){
        app('debugbar')->disable();
        $requestArr =  Input::toArray();   
        \App\Repositories\LogRepository::add('api::upsertTicket called', $requestArr, 'info', 'mobile');  

        $ticketId = Input::get('ticketId',null);//only if known (after scanning one with the phone)
        $ticketHash = Input::get('ticketHash',null);//only if known (after scanning one with the phone)
        $ticket = null;
        if($ticketId){
            $ticket = $this->ticketRepository->findWithoutFail($ticketId);
            if($ticket->pic !== null){
                \App\Repositories\LogRepository::add('api::upsertTicket - error:photo-already-defined' , [], 'warning', 'mobile');  
                return response()->json([
                    'error' => 'photo-already-defined',
                ]);
            }
        }

        //uploading a photo
        if ($file = $request->file('pic'))
        {
            $fileName        = $file->getClientOriginalName();
            $extension       = $file->getClientOriginalExtension() ?: 'png';
            $folderName      = storage_path('app/protected/students-photos');//actually not 'students' but more 'diplomas owners'
            $safeName = null;
            if($ticketId){
                $safeName  = "{$ticketId}.{$extension}";
            }else{//this should not actually happen
                $safeName        = 'ticket-unknown-' . str_random(10).'.'.$extension;
            }
            
            $file->move($folderName, $safeName);
        }

        
        $ticket->pic = isset($safeName)?$safeName:null;
        $ticket->save();

        //url to open by mobile app
        $openUrl = '';
        $openUrl = 'https://google.com';//testowo
        return response()->json([
            'error' => 0,
            'openUrl' => $openUrl,
        ]);        
    }

    /**
     * Adds or updates user
     * In any case this returns a new user record (json) including user's ID in the autenticalia_user key.
     * Right now always expect a Facebook user data, i.e. 'id' is a facebook user id.
     * Also method === 'facebook' 
     */
    public function userRegister(Request $request){
        $requestArr =  $request->toArray();   
        \App\Repositories\LogRepository::add('api::userRegister:',$requestArr,'info','api');    
        $mobileUserData = null;//mainly facebook.

        if(empty($requestArr['user']) || $requestArr['method'] !== 'facebook'){
            throw new \Exception ('Bad api call');
        }
        $mobileUserData = $requestArr['user'];
        $response = [
            'debug' => 'test',
        ];
        $autenticaliaUser = null;
        try{
        
            if($mobileUserData && !empty($mobileUserData['id'])){
                $autenticaliaUser = self::upsertUserBasedOnFB($mobileUserData);
            };
        }catch(Exception $e){
            $response['error'] = $e->getMessage();
            \App\Repositories\LogRepository::add('error',$response['error'],'error','api'); 
        }
        $response['user'] = $autenticaliaUser;
        return response()->json($response);
    }   

    
    /**
     * Statistics, feeds etc. Right now only for website. Called by ajax. Returns json.
     * @todo: we need to decide who have aceess to what. Right now only authed users.
     */
    public function get(Request $request){
        app('debugbar')->disable();
        if(!Sentinel::check()){//right now only logged in users
            die ('No access allowed');
        }
        if (!$request->isJson()) {
            //...
        }        


        /* 
        request body: 
        we expect an array of queries.
        {
            queries: 
            [
                {what: 'accessLog','period_days': 7},
                {what: 'general','period_days': 'all'},
            ]
        }
        */
        $requestArr =  $request->toArray();   
        
        //result:
        $result = [
            'debug' => [
                
            ] 
        ];
      
        foreach ($requestArr['queries'] as $query){
            //used probably only by the big map on the dashboard or maybe also 
            //the tickets details view 
            if($query['what'] === 'access_log'){
                
                $accLog = TicketAccessLog::select('tickets_access_log.*');
                if(!empty($query['span_last_days'])){
                    $dateFrom = (new \DateTime())->modify("-{$query['span_last_days']} day");
                    $accLog->where('dt', '>=', $dateFrom->format('Y-m-d'));
                }
                //this is most probably used by tickets details view
                if(isset($query['ticket_id'])){
                    $accLog->where('ticket_id',  $query['ticket_id']);
                }

                $accLog = $accLog->get();
                $result['access_log'] = [];
                foreach($accLog as $logItem){
                  
                    //this whole thing here is because we don't want to reveal too much info, because it's 
                    //easy to see it by users who maybe should not to able to see it
                    $arrItem = $logItem->toArray();
                    //this is possible during heavy development, deleting data etc, but should
                    //not exist in production:
                    if(/*empty($logItem->user) ||*/ empty($logItem->ticket)){
                       continue;
                    }
                    if(!Sentinel::inRole('admin')){
                        if($logItem->ticket->product && $logItem->ticket->product->category->user->id !== Sentinel::getUser()->id){
                            continue;//@todo: this should be done via the sql query above, not here in a loop.
                        }                       
                    }                    
                    if($logItem->user){
                        $arrItem['user'] = Arr::only($logItem->user->toArray(),
                            ['id','fb_id','first_name','last_name','email','pic']
                        );
                        if($arrItem['user']['pic']){
                            $arrItem['user']['pic_url'] = url('/').'/uploads/users/'.$arrItem['user']['pic'];
                        }else{
                            $arrItem['user']['pic_url'] = null;
                        }
                    }   
                   
                    $arrItem['ticket'] = Arr::only($logItem->ticket->toArray(),['id']);;
                    if($logItem->ticket->product){
                        $arrItem['ticket']['product'] = Arr::only($logItem->ticket->product->toArray(),['id','name']);
                        $arrItem['ticket']['product']['category'] = Arr::only($logItem->ticket->product->category->toArray(),['id','name']);
                        //well, the 'customer':
                        $arrItem['ticket']['product']['category']['user'] = Arr::only($logItem->ticket->product->category->user->toArray(),['first_name','last_name','email']);
                    }else{//no product, maybe a diploma?
                        $arrItem['ticket']['product'] = [];
                        $arrItem['ticket']['product']['category'] = [];
                        $arrItem['ticket']['product']['category']['user'] = [];
                    }
                    $result['access_log'][]= $arrItem;
                }
            }
            //for the general stats stuff like 'scans' etc
            if($query['what'] === 'general'){
                $result['general'] = [];
                $dateFrom = empty($query['span_last_days'])?null:(new \DateTime())->modify("-{$query['span_last_days']} day");
                $dateTo = null;
                $conditions = [
                    'dateFrom' => $dateFrom,
                    'dateTo' => $dateTo,
                ];
                //if cur user is not admin - limiting to cur user id
                if(!Sentinel::inRole('admin')){
                    //ticket's products' category's 'owner'
                    $conditions['customer_id'] = Sentinel::getUser()->id;
                }
                $result['general']['accesses_total'] = $this->getAccessLogStats($conditions);
                $result['general']['accesses_valid'] = $this->getAccessLogStats($conditions + ['result' => 200]);
                $result['general']['accesses_invalid'] = $this->getAccessLogStats($conditions + ['result' => 'invalid']);
                $result['general']['accesses_nonapp'] = $this->getAccessLogStats($conditions + ['userType' => 'noapp']);
            }
            //best 'customers', 'products'
            if($query['what'] === 'best'){
                $dateFrom = empty($query['span_last_days'])?null:(new \DateTime())->modify("-{$query['span_last_days']} day");
                $dateTo = null;
                $conditions = [
                    'dateFrom' => $dateFrom,
                    'dateTo' => $dateTo,
                ];
                $result['best'] = [];
                if(Sentinel::inRole('admin')){
                    //these are *not* recent, 'recent' are below in 'what' == recent
                    $result['best']['tickets'] = $this->ticketAccessLogRepository->getByTickets();
                    $result['best']['products'] = $this->ticketAccessLogRepository->getByProducts();
                    $result['best']['customers'] = $this->ticketAccessLogRepository->getByCustomers();

                    $result['best']['countries'] = $this->ticketAccessLogRepository->getByCountries();
                    $result['best']['continents'] = $this->ticketAccessLogRepository->getByContinents();

                    $result['best']['oss'] = $this->ticketAccessLogRepository->getByOss();
                    $result['best']['browsers'] = $this->ticketAccessLogRepository->getByBrowsers();
                }
            }
            if($query['what'] === 'recent'){
                //this is a bit different that the above if what == 'access_log' - it is supposed to be similar to 
                //the above if what === 'best', i.e. in terms of data returned back, because it is used 
                //in the same place - feed in dashboard.
                $dateFrom = empty($query['span_last_days'])?null:(new \DateTime())->modify("-{$query['span_last_days']} day");
                $dateTo = null;
                $conditions = [
                    'dateFrom' => $dateFrom,
                    'dateTo' => $dateTo,
                ];                
                $customerId = Sentinel::inRole('admin')?null:Sentinel::getUser()->id;
                $result['recent'] = $this->ticketAccessLogRepository->getRecent(10,$customerId,$conditions);
            }
            if($query['what'] === 'server_load'){
                $load = $this->getCpuUsage();
                $result['server_load'] = $load['user']??0;
            }
        }
        return response()->json($result);
    }
    
    /**
     * used by  this::get - all the params are optional.
     * this is so darn specific for this controller that it's here, not the model or repo to not pollute them.
     * @param conditions array (all can be null): dateFrom, dateTo, result , userType
     */
    protected function getAccessLogStats(array $conditions){

        //*totals* (depending on where)
        $builder = \DB::table('tickets_access_log')
            ->select(\DB::raw('count(*) as items_count'));
        $builder = $this->buildAccessLogStatsWhere($builder, $conditions);

        $count = $builder->first()->items_count;

        //*periodic* i.e. grouped by DAY or maybe MONTH, here we are making smth like: 
        //SELECT DATE_FORMAT(dt, '%Y-%m-%d'), count(id) FROM `tickets_access_log` GROUP BY DATE_FORMAT(dt, '%Y-%m-%d');
        $builder2 = \DB::table('tickets_access_log')
            ->select(\DB::raw("DATE_FORMAT(dt, '%Y-%m-%d') as period, count(tickets_access_log.id) as items_count"));
        $builder2 = $this->buildAccessLogStatsWhere($builder2, $conditions);
        $builder2->groupBy(\DB::raw("DATE_FORMAT(dt, '%Y-%m-%d')"));
        $periodic = $builder2->get();
        
        $result =   [
            //total for the given conditions:
            'count' =>  $count,
            //divided by day (or maybe other period)
            'periodic' => $periodic,
            'debug' => [
                
            ]
        ];
        return $result;
    }

    /**
     * adds ->where statements, returns a modified query builder
     * used by getAccessLogStats
     * this is so darn specific for this controller that it's here, not the model or repo to not pollute them.
     */
    protected function buildAccessLogStatsWhere($builder, array $conditions){
        
        if(!empty($conditions['dateFrom'])){
            $builder->where('dt', '>=', $conditions['dateFrom']);
        }
        if(!empty($conditions['dateTo'])){
            $builder->where('dt', '<=', $conditions['dateTo']);
        }
        //scan result
        if(isset($conditions['result'])){
            if($conditions['result'] === 'invalid'){//special case
                $builder->where('result', '<>', 200);
            }else{
                $builder->where('result', '=', $conditions['result']);
            }
        }
        //end user type:
        if(isset($conditions['userType'])){
            if($conditions['userType'] === 'app'){
                $builder->where('tickets_access_log.user_id', '<>', null);
            }elseif($conditions['userType'] === 'nonapp'){
                $builder->where('tickets_access_log.user_id', '=', null);
            }
        }
        if(isset($conditions['customer_id'])){
            $builder->join('tickets', 'tickets_access_log.ticket_id', '=', 'tickets.id');
            $builder->leftJoin('products', 'tickets.product_id', '=', 'products.id');
            $builder->leftJoin('categories', 'products.category_id', '=', 'categories.id');
            $builder->leftJoin('diplomas', 'diplomas.ticket_id', '=', 'tickets.id');
            $builder->where('categories.user_id','=',$conditions['customer_id']);
            $builder->orWhere('diplomas.school_id','=',$conditions['customer_id']);
        }
        return $builder;
    }

    /**
     * inserts or updates (if exists) a user.
     */
    public static function upsertUserBasedOnFB($fbData){
        //first - if there is no such user, we'll insert a dummy one, only to
        //update it a bit later. If it's already existing, we'll only update it.
        $userFbId = $fbData['id'];
        $autenticaliaUser = \App\User::where('fb_id', '=', $userFbId)->first();

        if($autenticaliaUser === null){
            $autenticaliaUser = Sentinel::register(array(
                //these are always required apparently
                'email' => $fbData['email'],
                'password' => uniqid(),
            ),true);
            //add user to 'end user' group
            $role = Sentinel::findRoleByName('end');
            $role->users()->attach($autenticaliaUser);        
            \App\Repositories\LogRepository::add('api\userRegister::created new user',$autenticaliaUser,'info','api');    
        }

        //updating the user
        $updateInfo = [
            'fb_id' => $fbData['id'],
            'email' => $fbData['email'] ?? null,
            'password' => uniqid(),
            'first_name' => $fbData['first_name'] ?? '',
            'last_name' => $fbData['last_name'] ?? '',
            //'pic'         => isset($safeName)?$safeName:'',
            'gender' => $fbData['gender'] ?? null,
            //'phone' => $request->get('phone'),
            //'country' => $request->get('country'),
            'address' => $fbData['location']['name'] ?? null,
            //'zip' => $request->get('zip'),
            //'facebook' => $request->get('facebook'),
        ];

        //avatar (picture) from fb
        if (!empty($fbData['picture']['data']['url']))
        {
            //$url = $fbData['picture']['data']['url'];//this works but this is better I guess:
            try{
                $url = "http://graph.facebook.com/{$fbData['id']}/picture?type=large";
                $uploadDirPath =  public_path() . '/uploads/users/';
                $safeName = str_random(10).'.jpg';

                $path = $uploadDirPath . $safeName;
                $file_path = fopen($path,'w');
                $client = new \GuzzleHttp\Client();
                $response = $client->get($url, ['sink' => $file_path]);
                //delete old pic if exists
                if($autenticaliaUser &&  File::exists($uploadDirPath.$autenticaliaUser->pic))
                {
                    File::delete($uploadDirPath.$autenticaliaUser->pic);
                }

                //save new file path into db
                $updateInfo['pic'] = $safeName;
            }catch(\Exception $e){
                \App\Repositories\LogRepository::add('api\userRegister error making an avatar',$e->getMessage(),'error','api');
            }
        }


        $user = Sentinel::update($autenticaliaUser, $updateInfo);
        /**
         * if *newly* registered then we'll only have id and those above fields here, i.e. email,
         * fb_id. Only when *updated* we'll also have 'last_login', 'subscribed' etc.
         */
        return $user;
    }
    /**
     * returns e.g. Array ( [user] => 95.1 [nice] => 0 [sys] => 4.9 [idle] => 0 )
     * normalized to 100% (no matter how many corers)
     * or null if there is any problem.
     */
    protected function getCpuUsage(){
        try{
            $stat1 = file('/proc/stat'); 
            usleep(1000*100); 
            $stat2 = file('/proc/stat'); 
            $info1 = explode(" ", preg_replace("!cpu +!", "", $stat1[0])); 
            $info2 = explode(" ", preg_replace("!cpu +!", "", $stat2[0])); 
            $dif = array(); 
            $dif['user'] = $info2[0] - $info1[0]; 
            $dif['nice'] = $info2[1] - $info1[1]; 
            $dif['sys'] = $info2[2] - $info1[2]; 
            $dif['idle'] = $info2[3] - $info1[3]; 
            $total = array_sum($dif); 
            $cpu = array(); 
            foreach($dif as $x=>$y) {
                if($total === 0){
                    $cpu[$x] = 0;   
                }else{
                    $cpu[$x] = round($y / $total * 100, 1);
                }
            }
        }catch(\Exception $e){
            return null;
        }
        return $cpu;
    }

    //playing around, sandbox
    public function tests(){

        //$dir = storage_path('app/protected/students-photos');dump($dir);
        //var_dump(\Storage::disk('local')->exists('protected/qr-codes/filedd.txt', 'Contents'));       
        // searching for a user:

        // $userFbId = 123;
        // $userFound = \App\User::where('fb_id', '=', $userFbId)->first();
        // dump($userFound);
    }
   
}