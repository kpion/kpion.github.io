<?php
/**
 * uploaded by Students! It is not in any way related to generated diplomas by the api.
 */
namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Support\Facades\Input;
// use App\Http\Requests\CreateDiplomaRequest;
// use App\Http\Requests\UpdateDiplomaRequest;
use App\Repositories\DiplomaRepository;
use App\Http\Controllers\AppBaseController as InfyOmBaseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Lang;
use App\Models\Diploma;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;
use Sentinel;
use App\Repositories\SchoolRepository;
use App\Repositories\TicketRepository;

class DiplomaController extends InfyOmBaseController
{
    /** @var  diplomaRepository */
    private $diplomaRepository;

    /** @var  SchoolRepository */
    private $schoolRepository;

    /** @var  TicketRepository */
    private $ticketRepository;

    
    public function __construct(DiplomaRepository $diplomaRepo, SchoolRepository $schoolRepo,TicketRepository $ticketRepo)
    {
        $this->diplomaRepository = $diplomaRepo;
        $this->schoolRepository = $schoolRepo;
        $this->ticketRepository = $ticketRepo;
    }

    /**
     * Display a listing of the Diploma.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {

        \App\Helpers\Utils::setBackUrl();    
        $categryId = Input::get('school',null);
        $school = $categryId?$this->schoolRepository->find($categryId):null;

        $diplomas = $this->diplomaRepository->getBy($categryId, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);        
        return view('admin.diplomas.index',['diplomas' => $diplomas,'school' => $school]);
    }

    /**
     * Show the form for creating a new Diploma.
     * in the url we can have optional ?school=<id>
     * @return Response
     */
    public function create(Request $request)
    {
        //to display a select
        $schools = $this->schoolRepository->getBy(null, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);        
        //$schools = [];
        //useful when creating a new diploma. May be null
        //$requestedSchool = $request->get('school')? $this->schoolRepository->find($request->get('school')):null;        
        //return view('admin.diplomas.create',['schools' => $schools,'requestedSchool' => $requestedSchool]);
        return view('admin.diplomas.create',['schools' => $schools]);
    }

    /**
     * Show the form for creating a new Diploma in the wizard version, with also uploading user ident card scans
     * in the url we can have optional ?school=<id>
     * @return Response
     */
    public function createWizard(Request $request)
    {
        //to display a select
        $schools = $this->schoolRepository->getBy(null, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);        
        return view('admin.diplomas.create-wizard',['schools' => $schools]);
    }
    /**
     * Store a newly created Diploma in storage.
     *
     * @param CreateDiplomaRequest $request
     *
     * @return Response
     */
    public function store(Request $request)
    {
        $input = $request->all();

        $studentId = Sentinel::getUser()->id;

        //upload DIPLOMA image
        if ($file = $request->file('diplomaPic'))
        {
            $fileName        = $file->getClientOriginalName();
            $extension       = $file->getClientOriginalExtension() ?: 'png';
            $folderName      = '/uploads/diplomas/';
            $destinationPath = public_path() . $folderName;
            $safeName        = str_random(10).'.'.$extension;
            $file->move($destinationPath, $safeName);
            $input['pic'] = isset($safeName)?$safeName:'';
        }
    
        //dump($input);die();

        $diploma = $this->diplomaRepository->create($input);
        //upload front ident image
        if ($file = $request->file('ident_doc_front_pic'))
        {
            $fileName        = $file->getClientOriginalName();
            $extension       = $file->getClientOriginalExtension() ?: 'png';
            $folderName      = '/uploads/idents/';
            $destinationPath = public_path() . $folderName;
            $safeName        = "{$studentId}-front.$extension";
            $file->move($destinationPath, $safeName);
            $diploma->student->ident_doc_front_pic = $safeName;
            //$input['pic'] = isset($safeName)?$safeName:'';
        }
        //upload back ident image
        if ($file = $request->file('ident_doc_back_pic'))
        {
            $fileName        = $file->getClientOriginalName();
            $extension       = $file->getClientOriginalExtension() ?: 'png';
            $folderName      = '/uploads/idents/';
            $destinationPath = public_path() . $folderName;
            $safeName        = "{$studentId}-back.$extension";
            $file->move($destinationPath, $safeName);
            $diploma->student->ident_doc_back_pic = $safeName;
            
            //$input['pic'] = isset($safeName)?$safeName:'';
        }      
        $ticketData = [
            //product_id
            //created_at
            //updated_at
            'diploma_id' => $diploma->id,
            'deleted_at' => NULL,
            'type' => 'qr',
            //hash
            'comment' => 'for a diploma',
            //appearance
            //generated_qr_code
            'limit_count' => null,
            'limit_dt' => null,            
        ];        
        $ticket = $this->ticketRepository->create($ticketData);     
        $ticket->createQrCode();     
        $diploma->ticket_id = $ticket->id;
        $diploma->save();    
        $diploma->student->save();//wtf? why do I need to do it?    
        Flash::success('Diploma saved successfully.');

        return redirect(route('admin.diplomas.index') . "?school={$diploma->school->id}");
    }

    /**
     * Display the specified Diploma.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $diploma = $this->diplomaRepository->findWithoutFail($id);

        if (empty($diploma)) {
            Flash::error('Diploma not found');

            return redirect(route('diplomas.index'));
        }

        return view('admin.diplomas.show')->with('diploma', $diploma);
    }

    /**
     * Show the form for editing the specified Diploma.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $diploma = $this->diplomaRepository->findWithoutFail($id);

        //to display a select
        $schools = $this->schoolRepository->getBy(null, Sentinel::inRole('admin')?null: Sentinel::getUser()->id);        

        if (empty($diploma)) {
            Flash::error('Diploma not found');

            return redirect(route('diplomas.index'));
        }

        return view('admin.diplomas.edit',['diploma'=> $diploma,'schools' => $schools]);
    }

    /**
     * Update the specified Diploma in storage.
     *
     * @param  int              $id
     * @param UpdateDiplomaRequest $request
     *
     * @return Response
     */
    public function update($id, Request $request)
    {
        
        $diploma = $this->diplomaRepository->findWithoutFail($id);
        $input = $request->all();
        //dump($input);die();
        if (empty($diploma)) {
            Flash::error('Diploma not found');
            return redirect(route('diplomas.index'));
        }
        //upload image
        if ($file = $request->file('pic'))
        {
            $fileName        = $file->getClientOriginalName();
            $extension       = $file->getClientOriginalExtension() ?: 'png';
            $folderName      = '/uploads/diplomas/';
            $destinationPath = public_path() . $folderName;
            $safeName        = str_random(10).'.'.$extension;
            $file->move($destinationPath, $safeName);
            //dump($destinationPath);die('dasf');
        }

        $input['pic'] = isset($safeName)?$safeName:'';
        if(isset($input['verified'])){
            $input['verified'] = 1;
        }
        $diploma = $this->diplomaRepository->update($input, $id);

        Flash::success('Diploma updated successfully.');

        //return redirect(route('admin.diplomas.index'));
        return redirect()->to(\App\Helpers\Utils::getBackUrl());
    }

    /**
     * Remove the specified Diploma from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
      public function getModalDelete($id = null)
      {
          $error = '';
          $model = '';
          $confirm_route =  route('admin.diplomas.delete',['id'=>$id]);
          return View('admin.layouts/modal_confirmation', compact('error','model', 'confirm_route'));

      }

       public function getDelete($id = null)
       {
           $sample = Diploma::destroy($id);

           // Redirect to the group management page
           return redirect(route('admin.diplomas.index'))->with('success', Lang::get('message.success.delete'));

       }

}
