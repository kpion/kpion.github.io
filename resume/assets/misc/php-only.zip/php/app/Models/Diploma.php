<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use App\Models\Ticket;

use App\Models\Category;

use Intervention\Image\ImageManagerStatic as Image;
use Sentinel;

class Diploma extends Model
{
    use SoftDeletes;

    public $table = 'diplomas';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'name',
        'school_id',
        'student_id',
        'ticket_id',
        'pic',
        'verified',
        
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'name' => 'string',
        'school_id' => 'integer',
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        
    ];
    public static function boot()
    {
        parent::boot();

        self::creating(function($model){
            //$model->hash = hash('sha256',uniqid());
            $model->student_id = Sentinel::getUser()->id;
        });
        self::created(function($model){
            
        });        
    }

    //weird, but correct - school is a user.
    public function school()
    {
        //return $this->belongsTo(User::class);
        return $this->belongsTo('App\User','school_id');
    }	

    //weird, but correct - student is also  a user.
    public function student()
    {
        //return $this->belongsTo(User::class);
        return $this->belongsTo('App\User','student_id');
    }	    

    //
    public function ticket()
    {
        //return $this->belongsTo(User::class);
        return $this->hasOne(Ticket::class);
    }	    
    
    /**
     * Returns a thumb of the main diploma image.
     * If we want a full image, simply access the 'pic' property of this object.
     * @param bool $url - if true, full url will be returned, ready for use in <img src =...>
     *      otherwise, if false, a sever path to ... /uploads/diplomas/thumbs/thePic' 
     * 
     * @param $default - if none pic defined, $default will be returned
     */
    public function getThumb($url = true, $default = 'http://placehold.it/64x64'){
        if(empty($this->pic)){
            return $default;
        }
        
        $srcFilePath = public_path() . '/uploads/diplomas/' . $this->pic;
        $destFilePath = public_path() . '/uploads/diplomas/thumbs/' . $this->pic;
        $recreate = true;
        if(file_exists($destFilePath) && filemtime($srcFilePath) <= filemtime($destFilePath)){
            $recreate = false;
        }
        if($recreate){
            try{
                $img = Image::make($srcFilePath);
                $img->resize(64, 64);
                $img->save($destFilePath); 
            }catch(\Exception $ex){
                return $default;
            }
        }
        if($url){
            return url('/') . '/uploads/diplomas/thumbs/' . $this->pic;       
        }else{
            return $destFilePath;       
        }
    }
}
